package com.game.cli;

import com.game.model.Difficulty;
import com.game.model.GameEngine;
import com.game.model.GameEngine.GuessResult;
import com.game.model.GameStats;

import java.util.Scanner;

/**
 * Modern Aesthetic Console Interface with ANSI true-color styling,
 * ASCII art banners, Unicode indicators, and game replay loops.
 */
public class AestheticCli {

    // ANSI Colors
    private static final String RESET = "\u001B[0m";
    private static final String BOLD = "\u001B[1m";
    private static final String DIM = "\u001B[2m";
    private static final String CYAN = "\u001B[38;2;6;182;212m";
    private static final String BLUE = "\u001B[38;2;59;130;246m";
    private static final String VIOLET = "\u001B[38;2;139;92;246m";
    private static final String GREEN = "\u001B[38;2;16;185;129m";
    private static final String AMBER = "\u001B[38;2;245;158;11m";
    private static final String RED = "\u001B[38;2;239;68;68m";
    private static final String WHITE = "\u001B[38;2;248;250;252m";
    private static final String GRAY = "\u001B[38;2;148;163;184m";

    private final GameEngine engine;
    private final GameStats stats;
    private final Scanner scanner;

    public AestheticCli() {
        this.engine = new GameEngine();
        this.stats = new GameStats();
        this.scanner = new Scanner(System.in);
    }

    public void start() {
        printBanner();

        boolean keepPlaying = true;
        while (keepPlaying) {
            Difficulty difficulty = promptDifficulty();
            playRound(difficulty);
            printSessionStats();
            keepPlaying = promptReplay();
        }

        printExitMessage();
    }

    private void printBanner() {
        System.out.println(CYAN + BOLD);
        System.out.println("  _  _ ___ ___        ____ _   _ _____ ____ ____  ");
        System.out.println(" | \\| | __/ _ \\ _____/ ___| | | | ____/ ___/ ___| ");
        System.out.println(" | .` | _| (_) |_____| |  _| | | |  _| \\___ \\___ \\ ");
        System.out.println(" |_|\\_|___\\___/      | |_| | |_| | |___ ___) |__) |");
        System.out.println("                      \\____|\\___/|_____|____/____/  " + VIOLET + "[v2.0]" + RESET);
        System.out.println(GRAY + "       ✦ Precision Number Deduction Challenge ✦" + RESET);
        System.out.println();
    }

    private Difficulty promptDifficulty() {
        System.out.println(BOLD + WHITE + "┌────────────────── SELECT DIFFICULTY ──────────────────┐" + RESET);
        Difficulty[] difficulties = Difficulty.values();
        for (int i = 0; i < difficulties.length; i++) {
            Difficulty d = difficulties[i];
            System.out.printf(GRAY + "│ " + CYAN + "[%d]" + WHITE + " %-9s" + GRAY + " Range: " + BLUE + "%-11s" + GRAY + " Attempts: " + AMBER + "%-2d" + GRAY + " │%n" + RESET,
                (i + 1), d.getDisplayName(), (d.getMin() + " - " + d.getMax()), d.getMaxAttempts());
        }
        System.out.println(BOLD + WHITE + "└───────────────────────────────────────────────────────┘" + RESET);

        while (true) {
            System.out.print(CYAN + BOLD + "➤ Choose difficulty (1-" + difficulties.length + ") [Default: 2]: " + RESET);
            String input = scanner.nextLine().trim();
            if (input.isEmpty()) {
                return Difficulty.MEDIUM;
            }
            try {
                int choice = Integer.parseInt(input);
                if (choice >= 1 && choice <= difficulties.length) {
                    return difficulties[choice - 1];
                }
            } catch (NumberFormatException ignored) {}
            System.out.println(RED + "Invalid selection. Please choose a valid number." + RESET);
        }
    }

    private void playRound(Difficulty difficulty) {
        engine.startRound(difficulty);

        System.out.println();
        System.out.printf(BOLD + GREEN + "✔ Starting %s Mode! Secret number generated between %d and %d.%n" + RESET,
            difficulty.getDisplayName(), difficulty.getMin(), difficulty.getMax());
        System.out.printf(GRAY + "You have " + AMBER + BOLD + "%d attempts" + RESET + GRAY + " to find it. Good luck!%n%n" + RESET,
            difficulty.getMaxAttempts());

        while (!engine.isFinished()) {
            printRangeBar();
            int guess = promptGuess();

            GuessResult result = engine.processGuess(guess);
            printResult(result);
        }
    }

    private void printRangeBar() {
        int rem = engine.getRemainingAttempts();
        int max = engine.getMaxAttempts();

        // Build attempts gauge: [●●●○○]
        StringBuilder gauge = new StringBuilder();
        for (int i = 0; i < max; i++) {
            if (i < rem) {
                gauge.append(GREEN).append("●").append(RESET);
            } else {
                gauge.append(GRAY).append("○").append(RESET);
            }
        }

        System.out.printf(GRAY + "Zone: " + CYAN + BOLD + "[%d ... %d]" + RESET +
            GRAY + "  |  Attempts: %s " + BOLD + "(%d/%d left)" + RESET + "%n",
            engine.getNarrowedMin(), engine.getNarrowedMax(), gauge, rem, max);
    }

    private int promptGuess() {
        while (true) {
            System.out.print(CYAN + BOLD + "➤ Enter your guess: " + RESET);
            String line = scanner.nextLine().trim();
            try {
                return Integer.parseInt(line);
            } catch (NumberFormatException e) {
                System.out.println(RED + "✖ Please enter a valid integer." + RESET);
            }
        }
    }

    private void printResult(GuessResult result) {
        System.out.println();
        switch (result.getStatus()) {
            case CORRECT -> {
                stats.recordWin(result.getAttemptsUsed(), result.getScoreEarned(), result.getAttemptsRemaining());
                System.out.println(GREEN + BOLD + "═══════════════════════════════════════════════════" + RESET);
                System.out.printf(GREEN + BOLD + " 🎉 BULLSEYE! %d WAS THE SECRET NUMBER! 🎉%n" + RESET, result.getGuess());
                System.out.printf(WHITE + "    Guessed in " + CYAN + "%d attempts" + WHITE + " | Earned " + AMBER + "%d points!" + RESET + "%n",
                    result.getAttemptsUsed(), result.getScoreEarned());
                System.out.println(GREEN + BOLD + "═══════════════════════════════════════════════════" + RESET);
            }
            case TOO_HIGH -> {
                String prox = result.getProximity() != null ? "  [" + result.getProximity().getDescription() + "]" : "";
                System.out.printf(AMBER + BOLD + " 🔻 TOO HIGH! " + RESET + GRAY + "(%d is greater than secret)%n" + VIOLET + "%s" + RESET + "%n", result.getGuess(), prox);
            }
            case TOO_LOW -> {
                String prox = result.getProximity() != null ? "  [" + result.getProximity().getDescription() + "]" : "";
                System.out.printf(BLUE + BOLD + " 🔺 TOO LOW!  " + RESET + GRAY + "(%d is smaller than secret)%n" + VIOLET + "%s" + RESET + "%n", result.getGuess(), prox);
            }
            case GAME_OVER -> {
                stats.recordLoss();
                System.out.println(RED + BOLD + "═══════════════════════════════════════════════════" + RESET);
                System.out.printf(RED + BOLD + " 💀 OUT OF ATTEMPTS! The secret number was: %d%n" + RESET, result.getRevealedTarget());
                System.out.println(RED + BOLD + "═══════════════════════════════════════════════════" + RESET);
            }
            case OUT_OF_BOUNDS -> {
                System.out.println(AMBER + " ⚠️ " + result.getMessage() + RESET);
            }
            case ALREADY_GUESSED -> {
                System.out.println(AMBER + " ⚠️ " + result.getMessage() + RESET);
            }
        }
        System.out.println();
    }

    private void printSessionStats() {
        System.out.println(BOLD + VIOLET + "─── SESSION STATS ───" + RESET);
        System.out.printf(GRAY + "Played: " + WHITE + "%d" + GRAY + "  |  Won: " + GREEN + "%d (%.0f%%)" + GRAY +
            "  |  Streak: " + AMBER + "%d 🔥" + GRAY + "  |  Total Score: " + CYAN + "%d ⭐%n" + RESET,
            stats.getGamesPlayed(), stats.getGamesWon(), stats.getWinRate(),
            stats.getCurrentStreak(), stats.getTotalScore());
        System.out.println();
    }

    private boolean promptReplay() {
        System.out.print(WHITE + BOLD + "➤ Play again? (Y/n): " + RESET);
        String ans = scanner.nextLine().trim().toLowerCase();
        return ans.isEmpty() || ans.startsWith("y");
    }

    private void printExitMessage() {
        System.out.println(CYAN + BOLD + "\nThanks for playing NEO-GUESS! See you next time. 🚀" + RESET);
    }
}
