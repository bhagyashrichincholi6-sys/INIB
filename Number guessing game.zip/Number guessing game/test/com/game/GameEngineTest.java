package com.game;

import com.game.model.Difficulty;
import com.game.model.DuelMatch;
import com.game.model.GameEngine;
import com.game.model.GameEngine.GuessResult;
import com.game.model.GameEngine.Status;
import com.game.model.Leaderboard;
import com.game.model.LeaderboardEntry;

import java.util.Random;

/**
 * Self-contained unit test suite verifying core game logic and task requirements.
 */
public class GameEngineTest {

    private static int testsPassed = 0;
    private static int testsFailed = 0;

    public static void main(String[] args) {
        System.out.println("Running GameEngineTest Suite...\n");

        testRangeGeneration();
        testGuessFeedbackTooHighAndLow();
        testWinCondition();
        testLimitedAttemptsAndGameOver();
        testBoundsValidation();
        testReplayReset();
        testProximityAndHints();
        testLeaderboardAndDuelMatch();

        System.out.println("\n-------------------------------------------");
        System.out.printf("Test Results: %d Passed, %d Failed%n", testsPassed, testsFailed);
        System.out.println("-------------------------------------------");

        if (testsFailed > 0) {
            System.exit(1);
        }
    }

    private static void assertEquals(Object expected, Object actual, String testName) {
        if ((expected == null && actual == null) || (expected != null && expected.equals(actual))) {
            System.out.println(" [PASS] " + testName);
            testsPassed++;
        } else {
            System.err.printf(" [FAIL] %s - Expected: %s, Got: %s%n", testName, expected, actual);
            testsFailed++;
        }
    }

    private static void assertTrue(boolean condition, String testName) {
        if (condition) {
            System.out.println(" [PASS] " + testName);
            testsPassed++;
        } else {
            System.err.println(" [FAIL] " + testName + " - Expected true, got false");
            testsFailed++;
        }
    }

    // 1. Requirement 1: Random number generated within specified range
    private static void testRangeGeneration() {
        GameEngine engine = new GameEngine();
        for (Difficulty diff : Difficulty.values()) {
            for (int i = 0; i < 20; i++) {
                engine.startRound(diff);
                int target = engine.getTargetNumber();
                assertTrue(target >= diff.getMin() && target <= diff.getMax(),
                    "Target number in range for " + diff.getDisplayName());
            }
        }
    }

    // 2. Requirement 2: User input feedback for high and low
    private static void testGuessFeedbackTooHighAndLow() {
        // Deterministic random producing target 50
        Random fixedRandom = new Random() {
            @Override
            public int nextInt(int bound) {
                return 49; // For min=1, max=100 -> target = 1 + 49 = 50
            }
        };

        GameEngine engine = new GameEngine(fixedRandom);
        engine.startRound(1, 100, 10);
        assertEquals(50, engine.getTargetNumber(), "Target should be 50");

        // Guess lower
        GuessResult lowResult = engine.processGuess(30);
        assertEquals(Status.TOO_LOW, lowResult.getStatus(), "Guess 30 should be TOO_LOW");
        assertEquals(31, engine.getNarrowedMin(), "Narrowed min should be updated to 31");

        // Guess higher
        GuessResult highResult = engine.processGuess(70);
        assertEquals(Status.TOO_HIGH, highResult.getStatus(), "Guess 70 should be TOO_HIGH");
        assertEquals(69, engine.getNarrowedMax(), "Narrowed max should be updated to 69");
    }

    // 3. Requirement 3 & 4: Win Condition & Limited Attempts
    private static void testWinCondition() {
        Random fixedRandom = new Random() {
            @Override
            public int nextInt(int bound) {
                return 41; // Target = 1 + 41 = 42
            }
        };

        GameEngine engine = new GameEngine(fixedRandom);
        engine.startRound(1, 100, 5);

        GuessResult winResult = engine.processGuess(42);
        assertEquals(Status.CORRECT, winResult.getStatus(), "Guess 42 should be CORRECT");
        assertTrue(engine.isWon(), "Engine state isWon should be true");
        assertTrue(engine.isFinished(), "Engine state isFinished should be true");
        assertTrue(winResult.getScoreEarned() > 0, "Score should be calculated upon winning");
    }

    private static void testLimitedAttemptsAndGameOver() {
        Random fixedRandom = new Random() {
            @Override
            public int nextInt(int bound) {
                return 99; // Target = 100
            }
        };

        GameEngine engine = new GameEngine(fixedRandom);
        engine.startRound(1, 100, 3); // Only 3 attempts

        engine.processGuess(10);
        engine.processGuess(20);
        GuessResult finalResult = engine.processGuess(30);

        assertEquals(Status.GAME_OVER, finalResult.getStatus(), "Third wrong guess triggers GAME_OVER");
        assertTrue(engine.isFinished(), "Game should be marked finished");
        assertTrue(!engine.isWon(), "Game should NOT be won");
        assertEquals(0, engine.getRemainingAttempts(), "Zero attempts remaining");
    }

    private static void testBoundsValidation() {
        GameEngine engine = new GameEngine();
        engine.startRound(1, 50, 5);

        GuessResult outLow = engine.processGuess(0);
        assertEquals(Status.OUT_OF_BOUNDS, outLow.getStatus(), "0 is out of bounds [1..50]");

        GuessResult outHigh = engine.processGuess(55);
        assertEquals(Status.OUT_OF_BOUNDS, outHigh.getStatus(), "55 is out of bounds [1..50]");

        // Out of bounds shouldn't consume attempts
        assertEquals(5, engine.getRemainingAttempts(), "Attempts should not be consumed for out of bounds");
    }

    // 5. Requirement 5: Replay Option
    private static void testReplayReset() {
        GameEngine engine = new GameEngine();
        engine.startRound(Difficulty.EASY);
        engine.processGuess(1);
        engine.processGuess(2);

        // Reset round for replay
        engine.startRound(Difficulty.EASY);
        assertEquals(0, engine.getAttemptsUsed(), "Attempts used should reset to 0 on new round");
        assertEquals(Difficulty.EASY.getMaxAttempts(), engine.getRemainingAttempts(), "Remaining attempts should reset");
        assertTrue(!engine.isFinished(), "Round should not be finished");
        assertEquals(0, engine.getGuessHistory().size(), "Guess history should be empty");
    }

    private static void testProximityAndHints() {
        Random fixedRandom = new Random() {
            @Override
            public int nextInt(int bound) {
                return 49; // Target = 50
            }
        };

        GameEngine engine = new GameEngine(fixedRandom);
        engine.startRound(1, 100, 10);

        assertEquals(GameEngine.Proximity.BOILING_HOT, engine.calculateProximity(52), "Diff 2 is BOILING_HOT");
        assertEquals(GameEngine.Proximity.WARM, engine.calculateProximity(56), "Diff 6 is WARM");
        assertEquals(GameEngine.Proximity.LUKEWARM, engine.calculateProximity(62), "Diff 12 is LUKEWARM");
        assertEquals(GameEngine.Proximity.CHILLY, engine.calculateProximity(72), "Diff 22 is CHILLY");
        assertEquals(GameEngine.Proximity.FREEZING, engine.calculateProximity(95), "Diff 45 is FREEZING");

        // Hints
        String parity = engine.getParityHint();
        assertTrue(parity.contains("EVEN"), "Target 50 parity hint contains EVEN");

        String div = engine.getDivisibilityHint();
        assertTrue(div.contains("multiple of 10") || div.contains("divisible by 5"), "Target 50 divisibility hint works");
        assertEquals(2, engine.getHintsUsed(), "Two hints should be tracked as used");
    }

    private static void testLeaderboardAndDuelMatch() {
        // 1. Leaderboard ranking
        Leaderboard lb = new Leaderboard();
        lb.clear();
        LeaderboardEntry e1 = new LeaderboardEntry("PlayerA", 1000, 4, 12.0, "MEDIUM");
        LeaderboardEntry e2 = new LeaderboardEntry("PlayerB", 1500, 2, 5.5, "MEDIUM");
        lb.addEntry(e1);
        lb.addEntry(e2);

        assertEquals("PlayerB", lb.getEntries().get(0).getPlayerName(), "Higher score PlayerB ranked #1");
        assertEquals(2, lb.getEntries().size(), "Leaderboard has 2 entries");

        // 2. 2-Player Duel Match
        DuelMatch duel = new DuelMatch("Alice", "Bob", Difficulty.EASY);
        assertEquals(DuelMatch.Phase.PLAYER1_TURN, duel.getPhase(), "Starts with Player 1 turn");
        assertEquals("Alice", duel.getActivePlayerName(), "Active player is Alice");

        int target = duel.getSecretTarget();
        // Alice guesses correctly on first try
        GuessResult r1 = duel.processCurrentGuess(target);
        assertEquals(Status.CORRECT, r1.getStatus(), "Alice guesses correctly");
        assertEquals(DuelMatch.Phase.INTERMISSION, duel.getPhase(), "Duel enters INTERMISSION after P1 finishes");

        // Transition to Bob
        duel.startPlayer2Turn();
        assertEquals(DuelMatch.Phase.PLAYER2_TURN, duel.getPhase(), "Duel enters PLAYER2_TURN");
        assertEquals("Bob", duel.getActivePlayerName(), "Active player is now Bob");

        // Bob guesses wrong once, then correct
        int wrongGuess = (target == 1) ? 2 : 1;
        duel.processCurrentGuess(wrongGuess);
        duel.processCurrentGuess(target);

        assertEquals(DuelMatch.Phase.COMPLETED, duel.getPhase(), "Duel COMPLETED after both finish");
        assertTrue(duel.getWinnerName() != null, "Winner is determined");
        assertTrue(duel.getVictorySummary() != null, "Victory summary generated");
    }
}
