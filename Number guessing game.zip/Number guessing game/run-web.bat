@echo off
setlocal
title NEO-GUESS Web Edition

if not exist "bin" mkdir bin

echo [NEO-GUESS] Compiling sources...
javac -encoding UTF-8 -d bin src\com\game\model\*.java src\com\game\audio\*.java src\com\game\gui\*.java src\com\game\cli\*.java src\com\game\web\*.java src\com\game\Main.java
if %ERRORLEVEL% neq 0 (
    echo [ERROR] Compilation failed!
    pause
    exit /b %ERRORLEVEL%
)

echo [NEO-GUESS] Starting Web Server and Opening Browser...
java -cp bin com.game.Main --web
pause
