package com.game.model;

import java.io.Serializable;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;

/**
 * Represents an entry on the game leaderboard.
 */
public class LeaderboardEntry implements Serializable, Comparable<LeaderboardEntry> {
    private static final long serialVersionUID = 1L;

    private final String playerName;
    private final int score;
    private final int attempts;
    private final double timeSeconds;
    private final String difficulty;
    private final String dateFormatted;

    public LeaderboardEntry(String playerName, int score, int attempts, double timeSeconds, String difficulty) {
        this.playerName = (playerName == null || playerName.trim().isEmpty()) ? "Anonymous" : playerName.trim();
        this.score = score;
        this.attempts = attempts;
        this.timeSeconds = Math.round(timeSeconds * 10.0) / 10.0;
        this.difficulty = difficulty;
        this.dateFormatted = LocalDateTime.now().format(DateTimeFormatter.ofPattern("MMM dd, HH:mm"));
    }

    public LeaderboardEntry(String playerName, int score, int attempts, double timeSeconds, String difficulty, String dateFormatted) {
        this.playerName = playerName;
        this.score = score;
        this.attempts = attempts;
        this.timeSeconds = timeSeconds;
        this.difficulty = difficulty;
        this.dateFormatted = dateFormatted;
    }

    public String getPlayerName() { return playerName; }
    public int getScore() { return score; }
    public int getAttempts() { return attempts; }
    public double getTimeSeconds() { return timeSeconds; }
    public String getDifficulty() { return difficulty; }
    public String getDateFormatted() { return dateFormatted; }

    /**
     * Compare by score descending; tiebreaker is faster time ascending.
     */
    @Override
    public int compareTo(LeaderboardEntry other) {
        if (this.score != other.score) {
            return Integer.compare(other.score, this.score);
        }
        return Double.compare(this.timeSeconds, other.timeSeconds);
    }
}
