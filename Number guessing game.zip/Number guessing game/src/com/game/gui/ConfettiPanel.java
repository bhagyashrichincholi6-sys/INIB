package com.game.gui;

import javax.swing.JComponent;
import javax.swing.Timer;
import java.awt.Color;
import java.awt.Graphics;
import java.awt.Graphics2D;
import java.awt.RenderingHints;
import java.awt.geom.AffineTransform;
import java.awt.geom.Rectangle2D;
import java.util.ArrayList;
import java.util.List;
import java.util.Random;

/**
 * High-performance lightweight confetti particle system for win celebrations.
 */
public class ConfettiPanel extends JComponent {

    private static class Particle {
        double x, y;
        double vx, vy;
        double rotation;
        double rotationSpeed;
        double width, height;
        Color color;

        Particle(int screenWidth) {
            Random r = new Random();
            this.x = r.nextDouble() * Math.max(1, screenWidth);
            this.y = -20 - r.nextDouble() * 200;
            this.vx = (r.nextDouble() - 0.5) * 3.5;
            this.vy = 2.5 + r.nextDouble() * 4.5;
            this.rotation = r.nextDouble() * 360;
            this.rotationSpeed = (r.nextDouble() - 0.5) * 12;
            this.width = 7 + r.nextDouble() * 8;
            this.height = 10 + r.nextDouble() * 10;

            Color[] colors = {
                new Color(16, 185, 129),  // Emerald
                new Color(6, 182, 212),   // Cyan
                new Color(139, 92, 246),  // Violet
                new Color(245, 158, 11),  // Amber / Gold
                new Color(244, 63, 94),   // Rose
                new Color(59, 130, 246),  // Blue
                new Color(236, 72, 153)   // Pink
            };
            this.color = colors[r.nextInt(colors.length)];
        }

        void update() {
            x += vx;
            y += vy;
            rotation += rotationSpeed;
        }
    }

    private final List<Particle> particles = new ArrayList<>();
    private Timer animationTimer;
    private boolean active = false;
    private long startTime;

    public ConfettiPanel() {
        setOpaque(false);
    }

    public void triggerCelebration() {
        particles.clear();
        int count = 90;
        int w = Math.max(getWidth(), 600);
        for (int i = 0; i < count; i++) {
            particles.add(new Particle(w));
        }

        active = true;
        startTime = System.currentTimeMillis();

        if (animationTimer != null && animationTimer.isRunning()) {
            animationTimer.stop();
        }

        animationTimer = new Timer(16, e -> {
            boolean hasActive = false;
            int height = getHeight();

            for (Particle p : particles) {
                p.update();
                if (p.y < height + 50) {
                    hasActive = true;
                }
            }

            // Stop after particles leave or 4.5 seconds elapse
            if (!hasActive || (System.currentTimeMillis() - startTime > 4500)) {
                active = false;
                animationTimer.stop();
            }
            repaint();
        });
        animationTimer.start();
    }

    public void stopCelebration() {
        if (animationTimer != null && animationTimer.isRunning()) {
            animationTimer.stop();
        }
        active = false;
        particles.clear();
        repaint();
    }

    @Override
    protected void paintComponent(Graphics g) {
        super.paintComponent(g);
        if (!active || particles.isEmpty()) return;

        Graphics2D g2 = (Graphics2D) g.create();
        g2.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);

        for (Particle p : particles) {
            AffineTransform old = g2.getTransform();
            g2.translate(p.x, p.y);
            g2.rotate(Math.toRadians(p.rotation));
            g2.setColor(p.color);
            g2.fill(new Rectangle2D.Double(-p.width / 2, -p.height / 2, p.width, p.height));
            g2.setTransform(old);
        }

        g2.dispose();
    }
}
