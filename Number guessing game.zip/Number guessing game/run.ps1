# NEO-GUESS PowerShell Launcher
param(
    [switch]$Cli
)

$Host.UI.RawUI.WindowTitle = "NEO-GUESS Launcher"

if (!(Test-Path "bin")) {
    New-Item -ItemType Directory -Path "bin" | Out-Null
}

Write-Host "[NEO-GUESS] Compiling sources..." -ForegroundColor Cyan
$sources = Get-ChildItem -Recurse -Path "src" -Filter "*.java" | Select-Object -ExpandProperty FullName
& javac -encoding UTF-8 -d bin $sources

if ($LASTEXITCODE -ne 0) {
    Write-Host "[ERROR] Compilation failed!" -ForegroundColor Red
    exit $LASTEXITCODE
}

if ($Cli) {
    Write-Host "[NEO-GUESS] Launching CLI mode..." -ForegroundColor Green
    & java -cp bin com.game.Main --cli
} else {
    Write-Host "[NEO-GUESS] Launching Modern GUI..." -ForegroundColor Green
    Start-Process javaw -ArgumentList "-cp bin com.game.Main"
}
