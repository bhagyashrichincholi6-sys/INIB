package com.game.model;

import com.game.model.GameEngine.GuessResult;
import com.game.model.GameEngine.Status;

import java.util.Random;

/**
 * Manages a competitive 2-Player duel where both players compete
 * to solve the secret number. The fastest player to solve it wins the match!
 */
public class DuelMatch {

    public enum Phase {
        PLAYER1_TURN,
        INTERMISSION,
        PLAYER2_TURN,
        COMPLETED
    }

    private final String player1Name;
    private final String player2Name;
    private final Difficulty difficulty;
    private final int secretTarget;

    private Phase phase;
    private final GameEngine p1Engine;
    private final GameEngine p2Engine;

    private long p1StartTime;
    private double p1TotalTimeSeconds;
    private long p2StartTime;
    private double p2TotalTimeSeconds;

    private String winnerName;
    private String victorySummary;

    public DuelMatch(String p1Name, String p2Name, Difficulty difficulty) {
        this.player1Name = (p1Name == null || p1Name.trim().isEmpty()) ? "Player 1" : p1Name.trim();
        this.player2Name = (p2Name == null || p2Name.trim().isEmpty()) ? "Player 2" : p2Name.trim();
        this.difficulty = difficulty;

        // Generate a single secret target shared between both players for fair competition
        Random rng = new Random();
        this.secretTarget = difficulty.getMin() + rng.nextInt(difficulty.getMax() - difficulty.getMin() + 1);

        // Fixed target deterministic engine for both
        Random p1Rng = new Random() {
            @Override
            public int nextInt(int bound) { return secretTarget - difficulty.getMin(); }
        };
        Random p2Rng = new Random() {
            @Override
            public int nextInt(int bound) { return secretTarget - difficulty.getMin(); }
        };

        this.p1Engine = new GameEngine(p1Rng);
        this.p1Engine.startRound(difficulty.getMin(), difficulty.getMax(), difficulty.getMaxAttempts());

        this.p2Engine = new GameEngine(p2Rng);
        this.p2Engine.startRound(difficulty.getMin(), difficulty.getMax(), difficulty.getMaxAttempts());

        this.phase = Phase.PLAYER1_TURN;
        this.p1StartTime = System.currentTimeMillis();
    }

    public synchronized GuessResult processCurrentGuess(int guess) {
        if (phase == Phase.PLAYER1_TURN) {
            GuessResult res = p1Engine.processGuess(guess);
            if (p1Engine.isFinished()) {
                p1TotalTimeSeconds = (System.currentTimeMillis() - p1StartTime) / 1000.0;
                phase = Phase.INTERMISSION;
            }
            return res;
        } else if (phase == Phase.PLAYER2_TURN) {
            GuessResult res = p2Engine.processGuess(guess);
            if (p2Engine.isFinished()) {
                p2TotalTimeSeconds = (System.currentTimeMillis() - p2StartTime) / 1000.0;
                phase = Phase.COMPLETED;
                evaluateWinner();
            }
            return res;
        }

        return null;
    }

    public synchronized void startPlayer2Turn() {
        if (phase == Phase.INTERMISSION) {
            phase = Phase.PLAYER2_TURN;
            p2StartTime = System.currentTimeMillis();
        }
    }

    private void evaluateWinner() {
        boolean p1Won = p1Engine.isWon();
        boolean p2Won = p2Engine.isWon();

        if (p1Won && !p2Won) {
            winnerName = player1Name;
            victorySummary = String.format("👑 %s WINS! Only player to successfully crack the secret code (%d)!",
                player1Name, secretTarget);
        } else if (!p1Won && p2Won) {
            winnerName = player2Name;
            victorySummary = String.format("👑 %s WINS! Only player to successfully crack the secret code (%d)!",
                player2Name, secretTarget);
        } else if (!p1Won && !p2Won) {
            winnerName = "Nobody (Tie)";
            victorySummary = String.format("💀 Stalemate! Neither player found the number (%d) within the attempt limit.",
                secretTarget);
        } else {
            // Both won! Decided by completion speed, with fewest guesses as second tiebreaker!
            double timeDiff = Math.abs(p1TotalTimeSeconds - p2TotalTimeSeconds);

            if (p1TotalTimeSeconds < p2TotalTimeSeconds) {
                winnerName = player1Name;
                victorySummary = String.format("⚡ %s WINS ON SPEED! Solved in %.1fs vs %.1fs (%.1fs faster!) with %d guesses.",
                    player1Name, p1TotalTimeSeconds, p2TotalTimeSeconds, timeDiff, p1Engine.getAttemptsUsed());
            } else if (p2TotalTimeSeconds < p1TotalTimeSeconds) {
                winnerName = player2Name;
                victorySummary = String.format("⚡ %s WINS ON SPEED! Solved in %.1fs vs %.1fs (%.1fs faster!) with %d guesses.",
                    player2Name, p2TotalTimeSeconds, p1TotalTimeSeconds, timeDiff, p2Engine.getAttemptsUsed());
            } else {
                // Exact same tenth of second - check attempts
                if (p1Engine.getAttemptsUsed() < p2Engine.getAttemptsUsed()) {
                    winnerName = player1Name;
                    victorySummary = String.format("🎯 %s WINS ON ACCURACY! Used %d guesses vs %d guesses.",
                        player1Name, p1Engine.getAttemptsUsed(), p2Engine.getAttemptsUsed());
                } else if (p2Engine.getAttemptsUsed() < p1Engine.getAttemptsUsed()) {
                    winnerName = player2Name;
                    victorySummary = String.format("🎯 %s WINS ON ACCURACY! Used %d guesses vs %d guesses.",
                        player2Name, p2Engine.getAttemptsUsed(), p1Engine.getAttemptsUsed());
                } else {
                    winnerName = "Split Victory (Draw)";
                    victorySummary = "🤝 Incredibly matched! Both players solved in identical time and guesses!";
                }
            }
        }
    }

    public String getPlayer1Name() { return player1Name; }
    public String getPlayer2Name() { return player2Name; }
    public Difficulty getDifficulty() { return difficulty; }
    public Phase getPhase() { return phase; }
    public GameEngine getP1Engine() { return p1Engine; }
    public GameEngine getP2Engine() { return p2Engine; }
    public double getP1TotalTimeSeconds() { return p1TotalTimeSeconds; }
    public double getP2TotalTimeSeconds() { return p2TotalTimeSeconds; }
    public String getWinnerName() { return winnerName; }
    public String getVictorySummary() { return victorySummary; }
    public int getSecretTarget() { return secretTarget; }

    public GameEngine getActiveEngine() {
        return (phase == Phase.PLAYER2_TURN) ? p2Engine : p1Engine;
    }

    public String getActivePlayerName() {
        return (phase == Phase.PLAYER2_TURN) ? player2Name : player1Name;
    }
}
