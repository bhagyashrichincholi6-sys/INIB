package com.game.audio;

import javax.sound.midi.MidiChannel;
import javax.sound.midi.MidiSystem;
import javax.sound.midi.Synthesizer;

/**
 * Procedural audio manager powered by standard Java MIDI Synthesizer.
 * Requires zero external audio files and delivers instant tactile game feedback.
 */
public class SoundManager {
    private static SoundManager instance;

    private Synthesizer synthesizer;
    private MidiChannel channel;
    private boolean soundEnabled = true;
    private boolean initialized = false;

    private SoundManager() {
        initMidi();
    }

    public static synchronized SoundManager getInstance() {
        if (instance == null) {
            instance = new SoundManager();
        }
        return instance;
    }

    private void initMidi() {
        try {
            synthesizer = MidiSystem.getSynthesizer();
            synthesizer.open();
            MidiChannel[] channels = synthesizer.getChannels();
            if (channels != null && channels.length > 0) {
                channel = channels[0];
                // Instrument 11 = Vibraphone / Marimba style
                channel.programChange(11);
                initialized = true;
            }
        } catch (Exception e) {
            // MIDI unavailable or headless, gracefully disable sound
            initialized = false;
        }
    }

    public boolean isSoundEnabled() {
        return soundEnabled;
    }

    public void setSoundEnabled(boolean enabled) {
        this.soundEnabled = enabled;
    }

    public void toggleSound() {
        this.soundEnabled = !this.soundEnabled;
    }

    /**
     * Plays a single note asynchronously.
     */
    private void playNote(int note, int velocity, int durationMs) {
        if (!soundEnabled || !initialized || channel == null) return;

        new Thread(() -> {
            try {
                channel.noteOn(note, velocity);
                Thread.sleep(durationMs);
                channel.noteOff(note);
            } catch (Exception ignored) {
            }
        }, "SoundWorker").start();
    }

    /**
     * Subtle click for button presses.
     */
    public void playClick() {
        playNote(72, 60, 60);
    }

    /**
     * Played when guess is too low (lower-pitched tone).
     */
    public void playTooLow() {
        playNote(55, 75, 180);
    }

    /**
     * Played when guess is too high (higher-pitched tone).
     */
    public void playTooHigh() {
        playNote(84, 75, 180);
    }

    /**
     * Uplifting arpeggio played upon winning.
     */
    public void playVictory() {
        if (!soundEnabled || !initialized || channel == null) return;

        new Thread(() -> {
            try {
                int[] arpeggio = {60, 64, 67, 72, 76, 79, 84}; // C-Major celebration arpeggio
                for (int note : arpeggio) {
                    channel.noteOn(note, 90);
                    Thread.sleep(110);
                }
                Thread.sleep(300);
                for (int note : arpeggio) {
                    channel.noteOff(note);
                }
            } catch (Exception ignored) {
            }
        }, "VictoryMusic").start();
    }

    /**
     * Minor descending tones for game over.
     */
    public void playGameOver() {
        if (!soundEnabled || !initialized || channel == null) return;

        new Thread(() -> {
            try {
                int[] notes = {63, 60, 58, 55};
                for (int note : notes) {
                    channel.noteOn(note, 80);
                    Thread.sleep(160);
                    channel.noteOff(note);
                }
            } catch (Exception ignored) {
            }
        }, "GameOverSound").start();
    }

    public void close() {
        if (synthesizer != null && synthesizer.isOpen()) {
            try {
                synthesizer.close();
            } catch (Exception ignored) {}
        }
    }
}
