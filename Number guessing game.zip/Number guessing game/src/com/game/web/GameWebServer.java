package com.game.web;

import com.game.model.Difficulty;
import com.game.model.DuelMatch;
import com.game.model.GameEngine;
import com.game.model.GameEngine.GuessRecord;
import com.game.model.GameEngine.GuessResult;
import com.game.model.GameStats;
import com.game.model.Leaderboard;
import com.game.model.LeaderboardEntry;
import com.sun.net.httpserver.HttpExchange;
import com.sun.net.httpserver.HttpHandler;
import com.sun.net.httpserver.HttpServer;

import java.awt.Desktop;
import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.net.InetSocketAddress;
import java.net.URI;
import java.nio.charset.StandardCharsets;
import java.util.List;
import java.util.Set;
import java.util.concurrent.Executors;

/**
 * Built-in zero-dependency HTTP server delivering an ultra-aesthetic,
 * themed Web Application interface with Solo mode, 2-Player Versus Duel,
 * Hall of Fame Leaderboard, and REST API endpoints.
 */
public class GameWebServer {

    private final int port;
    private final GameEngine engine;
    private final GameStats stats;
    private final Leaderboard leaderboard;
    private DuelMatch activeDuel;
    private HttpServer server;

    public GameWebServer(int port) {
        this.port = port;
        this.engine = new GameEngine();
        this.stats = new GameStats();
        this.leaderboard = Leaderboard.getInstance();
    }

    public static void startAndOpen(int preferredPort) {
        int port = preferredPort;
        GameWebServer webServer = null;

        for (int p = port; p < port + 10; p++) {
            try {
                webServer = new GameWebServer(p);
                webServer.start();
                port = p;
                break;
            } catch (IOException e) {
                // Port in use, try next
            }
        }

        if (webServer == null) {
            System.err.println("Could not bind to any port between " + preferredPort + " and " + (preferredPort + 10));
            return;
        }

        String url = "http://localhost:" + port;
        System.out.println("\n========================================================");
        System.out.println(" 🚀 NEO-GUESS Web Server is live at: " + url);
        System.out.println(" Opening external browser...");
        System.out.println("========================================================\n");

        openBrowser(url);
    }

    public void start() throws IOException {
        server = HttpServer.create(new InetSocketAddress(port), 0);
        server.setExecutor(Executors.newCachedThreadPool());

        // Routes
        server.createContext("/", new StaticAppHandler());
        server.createContext("/api/state", new StateHandler());
        server.createContext("/api/new-game", new NewGameHandler());
        server.createContext("/api/guess", new GuessHandler());
        server.createContext("/api/hint", new HintHandler());
        server.createContext("/api/stats", new StatsHandler());
        server.createContext("/api/leaderboard", new LeaderboardHandler());
        server.createContext("/api/duel/start", new DuelStartHandler());
        server.createContext("/api/duel/guess", new DuelGuessHandler());
        server.createContext("/api/duel/p2-start", new DuelP2StartHandler());
        server.createContext("/api/duel/state", new DuelStateHandler());

        server.start();
    }

    private static void openBrowser(String url) {
        try {
            if (Desktop.isDesktopSupported() && Desktop.getDesktop().isSupported(Desktop.Action.BROWSE)) {
                Desktop.getDesktop().browse(new URI(url));
                return;
            }
        } catch (Exception ignored) {}

        try {
            Runtime.getRuntime().exec(new String[]{"rundll32", "url.dll,FileProtocolHandler", url});
        } catch (Exception ignored) {
            System.out.println("Please open your browser and navigate to: " + url);
        }
    }

    // Static Web App Handler

    private class StaticAppHandler implements HttpHandler {
        @Override
        public void handle(HttpExchange exchange) throws IOException {
            if (!"GET".equalsIgnoreCase(exchange.getRequestMethod())) {
                exchange.sendResponseHeaders(405, -1);
                return;
            }

            byte[] htmlBytes = getHtmlContent().getBytes(StandardCharsets.UTF_8);
            exchange.getResponseHeaders().set("Content-Type", "text/html; charset=UTF-8");
            exchange.sendResponseHeaders(200, htmlBytes.length);
            try (OutputStream os = exchange.getResponseBody()) {
                os.write(htmlBytes);
            }
        }
    }

    // Solo API Handlers

    private class StateHandler implements HttpHandler {
        @Override
        public void handle(HttpExchange exchange) throws IOException {
            sendJsonResponse(exchange, buildGameStateJson(null, null));
        }
    }

    private class NewGameHandler implements HttpHandler {
        @Override
        public void handle(HttpExchange exchange) throws IOException {
            if (!"POST".equalsIgnoreCase(exchange.getRequestMethod())) {
                exchange.sendResponseHeaders(405, -1);
                return;
            }

            String body = readBody(exchange);
            String diffName = parseJsonString(body, "difficulty");
            Difficulty diff = Difficulty.MEDIUM;
            if (diffName != null) {
                try {
                    diff = Difficulty.valueOf(diffName.toUpperCase());
                } catch (IllegalArgumentException ignored) {}
            }

            engine.startRound(diff);
            sendJsonResponse(exchange, buildGameStateJson(null, null));
        }
    }

    private class GuessHandler implements HttpHandler {
        @Override
        public void handle(HttpExchange exchange) throws IOException {
            if (!"POST".equalsIgnoreCase(exchange.getRequestMethod())) {
                exchange.sendResponseHeaders(405, -1);
                return;
            }

            String body = readBody(exchange);
            Integer guess = parseJsonInt(body, "guess");
            if (guess == null) {
                sendJsonResponse(exchange, "{\"error\": \"Missing or invalid 'guess' parameter\"}", 400);
                return;
            }

            GuessResult result = engine.processGuess(guess);
            Set<String> newAchievements = null;
            if (result.getStatus() == GameEngine.Status.CORRECT) {
                newAchievements = stats.recordWin(result.getAttemptsUsed(), result.getScoreEarned(), result.getAttemptsRemaining());
            } else if (result.getStatus() == GameEngine.Status.GAME_OVER) {
                stats.recordLoss();
            }

            sendJsonResponse(exchange, buildGameStateJson(result, newAchievements));
        }
    }

    private class HintHandler implements HttpHandler {
        @Override
        public void handle(HttpExchange exchange) throws IOException {
            if (!"POST".equalsIgnoreCase(exchange.getRequestMethod())) {
                exchange.sendResponseHeaders(405, -1);
                return;
            }

            String body = readBody(exchange);
            String type = parseJsonString(body, "type");
            String hintText = "divisibility".equalsIgnoreCase(type)
                ? engine.getDivisibilityHint()
                : engine.getParityHint();

            String json = String.format("{\"hint\":\"%s\",\"hintsUsed\":%d}", escapeJson(hintText), engine.getHintsUsed());
            sendJsonResponse(exchange, json);
        }
    }

    private class StatsHandler implements HttpHandler {
        @Override
        public void handle(HttpExchange exchange) throws IOException {
            sendJsonResponse(exchange, buildStatsJson());
        }
    }

    // Leaderboard Handler

    private class LeaderboardHandler implements HttpHandler {
        @Override
        public void handle(HttpExchange exchange) throws IOException {
            if ("GET".equalsIgnoreCase(exchange.getRequestMethod())) {
                sendJsonResponse(exchange, buildLeaderboardJson());
            } else if ("POST".equalsIgnoreCase(exchange.getRequestMethod())) {
                String body = readBody(exchange);
                String name = parseJsonString(body, "playerName");
                Integer score = parseJsonInt(body, "score");
                Integer attempts = parseJsonInt(body, "attempts");
                Double time = parseJsonDouble(body, "timeSeconds");
                String diff = parseJsonString(body, "difficulty");

                if (score != null) {
                    LeaderboardEntry entry = new LeaderboardEntry(
                        name != null ? name : "Anonymous",
                        score,
                        attempts != null ? attempts : 1,
                        time != null ? time : 0.0,
                        diff != null ? diff : "MEDIUM"
                    );
                    leaderboard.addEntry(entry);
                }
                sendJsonResponse(exchange, buildLeaderboardJson());
            } else {
                exchange.sendResponseHeaders(405, -1);
            }
        }
    }

    // 2-Player Duel Handlers

    private class DuelStartHandler implements HttpHandler {
        @Override
        public void handle(HttpExchange exchange) throws IOException {
            if (!"POST".equalsIgnoreCase(exchange.getRequestMethod())) {
                exchange.sendResponseHeaders(405, -1);
                return;
            }

            String body = readBody(exchange);
            String p1Name = parseJsonString(body, "p1Name");
            String p2Name = parseJsonString(body, "p2Name");
            String diffName = parseJsonString(body, "difficulty");

            Difficulty diff = Difficulty.MEDIUM;
            if (diffName != null) {
                try { diff = Difficulty.valueOf(diffName.toUpperCase()); } catch (Exception ignored) {}
            }

            activeDuel = new DuelMatch(p1Name, p2Name, diff);
            sendJsonResponse(exchange, buildDuelJson(null));
        }
    }

    private class DuelGuessHandler implements HttpHandler {
        @Override
        public void handle(HttpExchange exchange) throws IOException {
            if (!"POST".equalsIgnoreCase(exchange.getRequestMethod())) {
                exchange.sendResponseHeaders(405, -1);
                return;
            }

            if (activeDuel == null) {
                sendJsonResponse(exchange, "{\"error\": \"No active duel\"}", 400);
                return;
            }

            String body = readBody(exchange);
            Integer guess = parseJsonInt(body, "guess");
            if (guess == null) {
                sendJsonResponse(exchange, "{\"error\": \"Invalid guess\"}", 400);
                return;
            }

            GuessResult result = activeDuel.processCurrentGuess(guess);
            sendJsonResponse(exchange, buildDuelJson(result));
        }
    }

    private class DuelP2StartHandler implements HttpHandler {
        @Override
        public void handle(HttpExchange exchange) throws IOException {
            if (!"POST".equalsIgnoreCase(exchange.getRequestMethod())) {
                exchange.sendResponseHeaders(405, -1);
                return;
            }

            if (activeDuel != null) {
                activeDuel.startPlayer2Turn();
            }
            sendJsonResponse(exchange, buildDuelJson(null));
        }
    }

    private class DuelStateHandler implements HttpHandler {
        @Override
        public void handle(HttpExchange exchange) throws IOException {
            sendJsonResponse(exchange, buildDuelJson(null));
        }
    }

    // JSON builders

    private String buildLeaderboardJson() {
        StringBuilder sb = new StringBuilder("{\"entries\":[");
        List<LeaderboardEntry> list = leaderboard.getEntries();
        for (int i = 0; i < list.size(); i++) {
            LeaderboardEntry e = list.get(i);
            if (i > 0) sb.append(",");
            sb.append("{")
              .append("\"rank\":").append(i + 1).append(",")
              .append("\"name\":\"").append(escapeJson(e.getPlayerName())).append("\",")
              .append("\"score\":").append(e.getScore()).append(",")
              .append("\"attempts\":").append(e.getAttempts()).append(",")
              .append("\"timeSeconds\":").append(e.getTimeSeconds()).append(",")
              .append("\"difficulty\":\"").append(escapeJson(e.getDifficulty())).append("\",")
              .append("\"date\":\"").append(escapeJson(e.getDateFormatted())).append("\"")
              .append("}");
        }
        sb.append("]}");
        return sb.toString();
    }

    private String buildDuelJson(GuessResult lastResult) {
        if (activeDuel == null) return "{\"active\":false}";

        GameEngine activeEng = activeDuel.getActiveEngine();
        StringBuilder sb = new StringBuilder("{");
        sb.append("\"active\":true,");
        sb.append("\"p1Name\":\"").append(escapeJson(activeDuel.getPlayer1Name())).append("\",");
        sb.append("\"p2Name\":\"").append(escapeJson(activeDuel.getPlayer2Name())).append("\",");
        sb.append("\"difficulty\":\"").append(activeDuel.getDifficulty().name()).append("\",");
        sb.append("\"phase\":\"").append(activeDuel.getPhase().name()).append("\",");
        sb.append("\"activePlayer\":\"").append(escapeJson(activeDuel.getActivePlayerName())).append("\",");
        sb.append("\"min\":").append(activeEng.getMinRange()).append(",");
        sb.append("\"max\":").append(activeEng.getMaxRange()).append(",");
        sb.append("\"narrowedMin\":").append(activeEng.getNarrowedMin()).append(",");
        sb.append("\"narrowedMax\":").append(activeEng.getNarrowedMax()).append(",");
        sb.append("\"maxAttempts\":").append(activeEng.getMaxAttempts()).append(",");
        sb.append("\"attemptsUsed\":").append(activeEng.getAttemptsUsed()).append(",");
        sb.append("\"remainingAttempts\":").append(activeEng.getRemainingAttempts()).append(",");

        sb.append("\"p1Won\":").append(activeDuel.getP1Engine().isWon()).append(",");
        sb.append("\"p1Attempts\":").append(activeDuel.getP1Engine().getAttemptsUsed()).append(",");
        sb.append("\"p1Time\":").append(activeDuel.getP1TotalTimeSeconds()).append(",");

        sb.append("\"p2Won\":").append(activeDuel.getP2Engine().isWon()).append(",");
        sb.append("\"p2Attempts\":").append(activeDuel.getP2Engine().getAttemptsUsed()).append(",");
        sb.append("\"p2Time\":").append(activeDuel.getP2TotalTimeSeconds()).append(",");

        sb.append("\"winner\":\"").append(activeDuel.getWinnerName() != null ? escapeJson(activeDuel.getWinnerName()) : "").append("\",");
        sb.append("\"victorySummary\":\"").append(activeDuel.getVictorySummary() != null ? escapeJson(activeDuel.getVictorySummary()) : "").append("\",");

        // History of active player
        sb.append("\"history\":[");
        for (int i = 0; i < activeEng.getGuessHistory().size(); i++) {
            GuessRecord gr = activeEng.getGuessHistory().get(i);
            if (i > 0) sb.append(",");
            sb.append("{\"guess\":").append(gr.getGuess())
              .append(",\"status\":\"").append(gr.getStatus().name()).append("\"")
              .append(",\"proximity\":\"").append(gr.getProximity() != null ? gr.getProximity().name() : "NONE").append("\"")
              .append(",\"proximityDesc\":\"").append(gr.getProximity() != null ? escapeJson(gr.getProximity().getDescription()) : "").append("\"")
              .append(",\"attempt\":").append(gr.getAttemptNumber()).append("}");
        }
        sb.append("],");

        if (lastResult != null) {
            sb.append("\"lastResult\":{")
              .append("\"status\":\"").append(lastResult.getStatus().name()).append("\",")
              .append("\"message\":\"").append(escapeJson(lastResult.getMessage())).append("\",")
              .append("\"guess\":").append(lastResult.getGuess()).append(",")
              .append("\"proximityDesc\":\"").append(lastResult.getProximity() != null ? escapeJson(lastResult.getProximity().getDescription()) : "").append("\"")
              .append("}");
        } else {
            sb.append("\"lastResult\":null");
        }

        sb.append("}");
        return sb.toString();
    }

    private String buildGameStateJson(GuessResult lastResult, Set<String> newAchievements) {
        StringBuilder sb = new StringBuilder("{");
        sb.append("\"min\":").append(engine.getMinRange()).append(",");
        sb.append("\"max\":").append(engine.getMaxRange()).append(",");
        sb.append("\"narrowedMin\":").append(engine.getNarrowedMin()).append(",");
        sb.append("\"narrowedMax\":").append(engine.getNarrowedMax()).append(",");
        sb.append("\"maxAttempts\":").append(engine.getMaxAttempts()).append(",");
        sb.append("\"attemptsUsed\":").append(engine.getAttemptsUsed()).append(",");
        sb.append("\"remainingAttempts\":").append(engine.getRemainingAttempts()).append(",");
        sb.append("\"hintsUsed\":").append(engine.getHintsUsed()).append(",");
        sb.append("\"isFinished\":").append(engine.isFinished()).append(",");
        sb.append("\"isWon\":").append(engine.isWon()).append(",");
        sb.append("\"difficulty\":\"").append(engine.getDifficulty().name()).append("\",");

        sb.append("\"history\":[");
        for (int i = 0; i < engine.getGuessHistory().size(); i++) {
            GuessRecord gr = engine.getGuessHistory().get(i);
            if (i > 0) sb.append(",");
            sb.append("{\"guess\":").append(gr.getGuess())
              .append(",\"status\":\"").append(gr.getStatus().name()).append("\"")
              .append(",\"proximity\":\"").append(gr.getProximity() != null ? gr.getProximity().name() : "NONE").append("\"")
              .append(",\"proximityDesc\":\"").append(gr.getProximity() != null ? escapeJson(gr.getProximity().getDescription()) : "").append("\"")
              .append(",\"attempt\":").append(gr.getAttemptNumber()).append("}");
        }
        sb.append("],");

        if (lastResult != null) {
            sb.append("\"lastResult\":{")
              .append("\"status\":\"").append(lastResult.getStatus().name()).append("\",")
              .append("\"message\":\"").append(escapeJson(lastResult.getMessage())).append("\",")
              .append("\"guess\":").append(lastResult.getGuess()).append(",")
              .append("\"proximity\":\"").append(lastResult.getProximity() != null ? lastResult.getProximity().name() : "NONE").append("\",")
              .append("\"proximityDesc\":\"").append(lastResult.getProximity() != null ? escapeJson(lastResult.getProximity().getDescription()) : "").append("\",")
              .append("\"scoreEarned\":").append(lastResult.getScoreEarned()).append(",")
              .append("\"revealedTarget\":").append(lastResult.getRevealedTarget() != null ? lastResult.getRevealedTarget() : "null")
              .append("},");
        } else {
            sb.append("\"lastResult\":null,");
        }

        sb.append("\"newAchievements\":[");
        if (newAchievements != null) {
            int i = 0;
            for (String a : newAchievements) {
                if (i++ > 0) sb.append(",");
                sb.append("\"").append(escapeJson(a)).append("\"");
            }
        }
        sb.append("],");

        sb.append("\"stats\":").append(buildStatsJson());
        sb.append("}");
        return sb.toString();
    }

    private String buildStatsJson() {
        StringBuilder sb = new StringBuilder("{");
        sb.append("\"gamesPlayed\":").append(stats.getGamesPlayed()).append(",");
        sb.append("\"gamesWon\":").append(stats.getGamesWon()).append(",");
        sb.append("\"currentStreak\":").append(stats.getCurrentStreak()).append(",");
        sb.append("\"bestStreak\":").append(stats.getBestStreak()).append(",");
        sb.append("\"totalScore\":").append(stats.getTotalScore()).append(",");
        sb.append("\"highScore\":").append(stats.getHighScore()).append(",");
        sb.append(String.format(java.util.Locale.US, "\"winRate\":%.1f,", stats.getWinRate()));

        sb.append("\"achievements\":[");
        int idx = 0;
        for (String a : stats.getAchievements()) {
            if (idx++ > 0) sb.append(",");
            sb.append("\"").append(escapeJson(a)).append("\"");
        }
        sb.append("]");
        sb.append("}");
        return sb.toString();
    }

    private void sendJsonResponse(HttpExchange exchange, String json) throws IOException {
        sendJsonResponse(exchange, json, 200);
    }

    private void sendJsonResponse(HttpExchange exchange, String json, int code) throws IOException {
        byte[] bytes = json.getBytes(StandardCharsets.UTF_8);
        exchange.getResponseHeaders().set("Content-Type", "application/json; charset=UTF-8");
        exchange.getResponseHeaders().set("Access-Control-Allow-Origin", "*");
        exchange.sendResponseHeaders(code, bytes.length);
        try (OutputStream os = exchange.getResponseBody()) {
            os.write(bytes);
        }
    }

    private String readBody(HttpExchange exchange) throws IOException {
        try (BufferedReader reader = new BufferedReader(new InputStreamReader(exchange.getRequestBody(), StandardCharsets.UTF_8))) {
            StringBuilder sb = new StringBuilder();
            String line;
            while ((line = reader.readLine()) != null) sb.append(line);
            return sb.toString();
        }
    }

    private String parseJsonString(String json, String key) {
        String pattern = "\"" + key + "\"\\s*:\\s*\"([^\"]+)\"";
        java.util.regex.Matcher m = java.util.regex.Pattern.compile(pattern).matcher(json);
        return m.find() ? m.group(1) : null;
    }

    private Integer parseJsonInt(String json, String key) {
        String pattern = "\"" + key + "\"\\s*:\\s*([0-9-]+)";
        java.util.regex.Matcher m = java.util.regex.Pattern.compile(pattern).matcher(json);
        if (m.find()) {
            try { return Integer.parseInt(m.group(1)); } catch (Exception ignored) {}
        }
        return null;
    }

    private Double parseJsonDouble(String json, String key) {
        String pattern = "\"" + key + "\"\\s*:\\s*([0-9.-]+)";
        java.util.regex.Matcher m = java.util.regex.Pattern.compile(pattern).matcher(json);
        if (m.find()) {
            try { return Double.parseDouble(m.group(1)); } catch (Exception ignored) {}
        }
        return null;
    }

    private String escapeJson(String s) {
        if (s == null) return "";
        return s.replace("\\", "\\\\").replace("\"", "\\\"").replace("\n", "\\n").replace("\r", "");
    }

    // HTML / CSS / JS Single-Page App

    private String getHtmlContent() {
        return """
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>NUMBER GUESSING GAME // NEO-GUESS</title>
  <link rel="preconnect" href="https://fonts.googleapis.com">
  <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
  <link href="https://fonts.googleapis.com/css2?family=Plus+Jakarta+Sans:wght@400;500;600;700;800;900&family=JetBrains+Mono:wght@500;700;800&family=Syne:wght@700;800;900&display=swap" rel="stylesheet">
  <style>
    :root {
      --bg-gradient: radial-gradient(circle at 10% 10%, rgba(236, 72, 153, 0.16), transparent 45%),
                     radial-gradient(circle at 90% 20%, rgba(139, 92, 246, 0.2), transparent 50%),
                     radial-gradient(circle at 50% 90%, rgba(6, 182, 212, 0.15), transparent 55%),
                     #090915;
      --card-bg: rgba(23, 20, 42, 0.75);
      --card-border: rgba(255, 255, 255, 0.1);
      --primary: #ec4899;
      --primary-hover: #f43f5e;
      --primary-glow: rgba(236, 72, 153, 0.45);
      --accent: #8b5cf6;
      --accent-glow: rgba(139, 92, 246, 0.4);
      --secondary: #06b6d4;
      --success: #10b981;
      --warning: #f59e0b;
      --danger: #ef4444;
      --text-main: #f8fafc;
      --text-muted: #94a3b8;
      --watermark-color: rgba(255, 255, 255, 0.035);
      --watermark-glow: rgba(236, 72, 153, 0.08);
    }

    body[data-theme="emerald"] {
      --bg-gradient: radial-gradient(circle at 15% 15%, rgba(16, 185, 129, 0.2), transparent 45%),
                     radial-gradient(circle at 85% 20%, rgba(6, 182, 212, 0.2), transparent 50%),
                     radial-gradient(circle at 50% 90%, rgba(52, 211, 153, 0.15), transparent 55%),
                     #04120f;
      --card-bg: rgba(9, 32, 27, 0.78);
      --card-border: rgba(52, 211, 153, 0.18);
      --primary: #10b981;
      --primary-hover: #059669;
      --primary-glow: rgba(16, 185, 129, 0.45);
      --accent: #06b6d4;
      --accent-glow: rgba(6, 182, 212, 0.4);
      --secondary: #f59e0b;
      --watermark-color: rgba(16, 185, 129, 0.04);
      --watermark-glow: rgba(16, 185, 129, 0.1);
    }

    body[data-theme="sunset"] {
      --bg-gradient: radial-gradient(circle at 10% 15%, rgba(245, 158, 11, 0.2), transparent 45%),
                     radial-gradient(circle at 90% 25%, rgba(244, 63, 94, 0.2), transparent 50%),
                     radial-gradient(circle at 50% 90%, rgba(217, 70, 239, 0.15), transparent 55%),
                     #12080e;
      --card-bg: rgba(35, 18, 25, 0.8);
      --card-border: rgba(245, 158, 11, 0.18);
      --primary: #f59e0b;
      --primary-hover: #d97706;
      --primary-glow: rgba(245, 158, 11, 0.45);
      --accent: #f43f5e;
      --accent-glow: rgba(244, 63, 94, 0.4);
      --secondary: #8b5cf6;
      --watermark-color: rgba(245, 158, 11, 0.04);
      --watermark-glow: rgba(245, 158, 11, 0.1);
    }

    * {
      box-sizing: border-box;
      margin: 0;
      padding: 0;
      font-family: 'Plus Jakarta Sans', sans-serif;
      user-select: none;
    }

    body {
      background: var(--bg-gradient);
      min-height: 100vh;
      color: var(--text-main);
      display: flex;
      flex-direction: column;
      align-items: center;
      justify-content: center;
      padding: 24px 16px;
      overflow-x: hidden;
      position: relative;
      transition: background 0.6s ease;
    }

    /* Cinematic Project Watermark in Background */
    .bg-watermark-container {
      position: fixed;
      top: 50%;
      left: 50%;
      transform: translate(-50%, -50%);
      width: 100vw;
      text-align: center;
      pointer-events: none;
      z-index: 1;
      display: flex;
      flex-direction: column;
      align-items: center;
      justify-content: center;
    }

    .bg-watermark-title {
      font-family: 'Syne', sans-serif;
      font-size: clamp(48px, 11vw, 150px);
      font-weight: 900;
      letter-spacing: -2px;
      line-height: 0.9;
      text-transform: uppercase;
      color: transparent;
      -webkit-text-stroke: 1.5px var(--watermark-color);
      text-shadow: 0 0 50px var(--watermark-glow);
      opacity: 0.85;
      white-space: nowrap;
      animation: floatBreath 8s ease-in-out infinite;
    }

    .bg-watermark-subtitle {
      font-family: 'JetBrains Mono', monospace;
      font-size: clamp(14px, 2.5vw, 32px);
      font-weight: 800;
      letter-spacing: 12px;
      text-transform: uppercase;
      color: var(--watermark-color);
      margin-top: 10px;
    }

    @keyframes floatBreath {
      0%, 100% { transform: translateY(0) scale(1); }
      50% { transform: translateY(-12px) scale(1.02); }
    }

    #ambientCanvas, #confettiCanvas {
      position: fixed;
      top: 0;
      left: 0;
      width: 100vw;
      height: 100vh;
      pointer-events: none;
    }
    #ambientCanvas { z-index: 2; }
    #confettiCanvas { z-index: 999; }

    .app-container {
      width: 100%;
      max-width: 720px;
      display: flex;
      flex-direction: column;
      gap: 14px;
      z-index: 10;
      position: relative;
    }

    /* Glass Cards */
    .card {
      background: var(--card-bg);
      backdrop-filter: blur(20px);
      -webkit-backdrop-filter: blur(20px);
      border: 1px solid var(--card-border);
      border-radius: 20px;
      padding: 18px 22px;
      box-shadow: 0 16px 40px rgba(0, 0, 0, 0.45);
      transition: all 0.3s ease;
    }

    /* Top Nav Mode Switcher */
    .mode-nav {
      display: grid;
      grid-template-columns: repeat(3, 1fr);
      gap: 8px;
      background: rgba(10, 8, 22, 0.6);
      padding: 6px;
      border-radius: 16px;
      border: 1px solid var(--card-border);
    }

    .mode-tab {
      background: transparent;
      border: none;
      color: var(--text-muted);
      font-weight: 800;
      font-size: 13px;
      padding: 10px 14px;
      border-radius: 12px;
      cursor: pointer;
      display: flex;
      align-items: center;
      justify-content: center;
      gap: 6px;
      transition: all 0.25s ease;
    }
    .mode-tab.active {
      background: linear-gradient(135deg, var(--primary), var(--accent));
      color: #fff;
      box-shadow: 0 4px 16px var(--primary-glow);
    }

    /* Header */
    .header {
      display: flex;
      justify-content: space-between;
      align-items: center;
    }

    .brand {
      display: flex;
      align-items: center;
      gap: 10px;
    }

    .brand h1 {
      font-size: 22px;
      font-weight: 900;
      letter-spacing: -0.5px;
      background: linear-gradient(135deg, #fff 25%, var(--primary));
      -webkit-background-clip: text;
      -webkit-text-fill-color: transparent;
    }

    .header-controls {
      display: flex;
      align-items: center;
      gap: 8px;
    }

    .player-profile-pill {
      background: rgba(255, 255, 255, 0.08);
      border: 1px solid var(--card-border);
      color: #fff;
      font-size: 12px;
      font-weight: 700;
      padding: 6px 12px;
      border-radius: 20px;
      cursor: pointer;
      display: flex;
      align-items: center;
      gap: 6px;
    }
    .player-profile-pill:hover {
      border-color: var(--primary);
    }

    .control-btn {
      background: rgba(255, 255, 255, 0.06);
      border: 1px solid var(--card-border);
      color: var(--text-main);
      padding: 6px 10px;
      border-radius: 10px;
      font-size: 13px;
      font-weight: 700;
      cursor: pointer;
      display: flex;
      align-items: center;
      gap: 4px;
      transition: all 0.2s ease;
    }

    /* Stats Bar */
    .stats-bar {
      display: grid;
      grid-template-columns: repeat(5, 1fr);
      gap: 8px;
      padding: 10px 16px;
    }
    .stat-item { text-align: center; }
    .stat-label { font-size: 10px; text-transform: uppercase; color: var(--text-muted); font-weight: 700; }
    .stat-val { font-size: 16px; font-weight: 800; color: #fff; font-family: 'JetBrains Mono', monospace; }

    /* Difficulty & Speedrun Timer */
    .diff-container { display: flex; flex-direction: column; gap: 10px; }
    .diff-header { display: flex; justify-content: space-between; align-items: center; }
    .diff-label { font-size: 11px; font-weight: 700; letter-spacing: 0.8px; color: var(--text-muted); text-transform: uppercase; }
    .timer-pill {
      font-family: 'JetBrains Mono', monospace; font-size: 12px; font-weight: 700;
      background: rgba(255, 255, 255, 0.06); padding: 3px 10px; border-radius: 20px;
      color: var(--secondary); border: 1px solid rgba(6, 182, 212, 0.2);
    }
    .diff-pills {
      display: grid; grid-template-columns: repeat(4, 1fr); gap: 6px;
      background: rgba(0, 0, 0, 0.25); padding: 4px; border-radius: 12px;
    }
    .diff-btn {
      background: transparent; border: none; color: var(--text-muted);
      font-weight: 700; font-size: 12px; padding: 7px; border-radius: 10px; cursor: pointer;
    }
    .diff-btn.active { background: linear-gradient(135deg, var(--primary), var(--accent)); color: #fff; }

    /* Thermal Proximity */
    .thermal-box {
      display: flex; align-items: center; justify-content: space-between;
      background: rgba(0, 0, 0, 0.2); border-radius: 14px; padding: 10px 16px;
    }
    .thermal-title { font-size: 11px; font-weight: 700; color: var(--text-muted); text-transform: uppercase; }
    .thermal-status { font-size: 13px; font-weight: 800; color: var(--text-main); }

    /* Range Slider */
    .range-box { display: flex; flex-direction: column; gap: 8px; }
    .range-labels { display: flex; justify-content: space-between; font-size: 12px; font-weight: 700; color: var(--text-muted); font-family: 'JetBrains Mono', monospace; }
    .range-track { position: relative; width: 100%; height: 12px; background: rgba(0, 0, 0, 0.35); border-radius: 10px; }
    .range-active {
      position: absolute; top: 0; height: 100%;
      background: linear-gradient(90deg, var(--secondary), var(--primary), var(--accent));
      border-radius: 10px; transition: all 0.35s ease;
    }
    .active-zone-badge { text-align: center; font-size: 13px; font-weight: 700; font-family: 'JetBrains Mono', monospace; }
    .active-zone-badge span { color: var(--primary); }

    /* Attempts Gauge */
    .attempts-wrapper { display: flex; justify-content: space-between; align-items: center; }
    .gauge-dots { display: flex; gap: 6px; }
    .dot { width: 11px; height: 11px; border-radius: 6px; background: #334155; }
    .dot.filled { background: var(--primary); box-shadow: 0 0 8px var(--primary-glow); }
    .dot.warning { background: var(--warning); }
    .dot.danger { background: var(--danger); }

    /* Hint Lifelines */
    .lifelines-row { display: flex; gap: 8px; }
    .hint-btn {
      flex: 1; background: rgba(255, 255, 255, 0.05); border: 1px dashed rgba(255, 255, 255, 0.15);
      color: var(--text-main); font-size: 12px; font-weight: 700; padding: 8px 12px;
      border-radius: 12px; cursor: pointer;
    }
    .hint-btn:hover { background: rgba(255, 255, 255, 0.1); border-color: var(--secondary); }

    /* Input Card */
    .input-card { display: flex; flex-direction: column; align-items: center; gap: 14px; padding: 22px 20px; }
    .input-row { display: flex; width: 100%; gap: 10px; }
    .guess-input {
      flex: 1; background: rgba(0, 0, 0, 0.35); border: 2px solid rgba(255, 255, 255, 0.12);
      border-radius: 16px; padding: 12px 16px; font-size: 28px; font-weight: 800; color: #fff;
      text-align: center; font-family: 'JetBrains Mono', monospace; outline: none;
    }
    .guess-input:focus { border-color: var(--primary); box-shadow: 0 0 20px var(--primary-glow); }
    .guess-btn {
      background: linear-gradient(135deg, var(--primary), var(--accent)); border: none;
      color: #fff; font-weight: 800; font-size: 15px; padding: 0 24px; border-radius: 16px;
      cursor: pointer; box-shadow: 0 8px 20px var(--primary-glow);
    }
    .guess-btn:disabled { opacity: 0.5; cursor: not-allowed; }

    /* Feedback Banner */
    .feedback-banner {
      width: 100%; padding: 14px; border-radius: 14px; text-align: center;
      background: rgba(0, 0, 0, 0.25); border: 1px solid rgba(255, 255, 255, 0.06);
    }
    .feedback-title { font-size: 15px; font-weight: 800; color: #fff; }
    .feedback-sub { font-size: 12px; color: var(--text-muted); margin-top: 3px; }
    .feedback-banner.success { background: rgba(16, 185, 129, 0.18); border-color: var(--success); }
    .feedback-banner.success .feedback-title { color: var(--success); }
    .feedback-banner.too-high { background: rgba(245, 158, 11, 0.18); border-color: var(--warning); }
    .feedback-banner.too-high .feedback-title { color: var(--warning); }
    .feedback-banner.too-low { background: rgba(6, 182, 212, 0.18); border-color: var(--secondary); }
    .feedback-banner.too-low .feedback-title { color: var(--secondary); }
    .feedback-banner.danger { background: rgba(239, 68, 68, 0.18); border-color: var(--danger); }
    .feedback-banner.danger .feedback-title { color: var(--danger); }

    /* Chips */
    .history-card { display: flex; flex-direction: column; gap: 8px; }
    .chips-flow { display: flex; flex-wrap: wrap; gap: 8px; min-height: 32px; }
    .chip {
      font-size: 12px; font-weight: 700; font-family: 'JetBrains Mono', monospace;
      padding: 5px 10px; border-radius: 10px; display: flex; align-items: center; gap: 4px;
    }
    .chip.high { background: rgba(245, 158, 11, 0.15); border: 1px solid var(--warning); color: var(--warning); }
    .chip.low { background: rgba(6, 182, 212, 0.15); border: 1px solid var(--secondary); color: var(--secondary); }
    .chip.correct { background: rgba(16, 185, 129, 0.2); border: 1px solid var(--success); color: var(--success); }
    .chip.over { background: rgba(239, 68, 68, 0.2); border: 1px solid var(--danger); color: var(--danger); }

    /* 2-Player Versus Duel Arena */
    .duel-arena { display: flex; flex-direction: column; gap: 14px; }
    .duel-setup-box { display: flex; flex-direction: column; gap: 12px; }
    .duel-inputs { display: grid; grid-template-columns: 1fr 1fr; gap: 12px; }
    .duel-input-group { display: flex; flex-direction: column; gap: 4px; }
    .duel-input-group label { font-size: 11px; font-weight: 700; color: var(--text-muted); text-transform: uppercase; }
    .duel-name-input {
      background: rgba(0, 0, 0, 0.35); border: 1px solid var(--card-border); border-radius: 12px;
      padding: 10px 14px; color: #fff; font-size: 14px; font-weight: 700; outline: none;
    }
    .duel-start-btn {
      background: linear-gradient(135deg, var(--primary), var(--accent)); border: none;
      color: #fff; font-weight: 800; font-size: 15px; padding: 12px; border-radius: 14px;
      cursor: pointer; box-shadow: 0 6px 18px var(--primary-glow);
    }
    .duel-hud {
      display: grid; grid-template-columns: 1fr 1fr; gap: 12px;
      background: rgba(0, 0, 0, 0.3); border-radius: 16px; padding: 12px 16px;
    }
    .hud-player { display: flex; flex-direction: column; gap: 2px; }
    .hud-player.active { border-bottom: 2px solid var(--primary); padding-bottom: 4px; }
    .hud-name { font-size: 13px; font-weight: 800; color: #fff; display: flex; align-items: center; gap: 6px; }
    .hud-stats { font-size: 11px; color: var(--text-muted); font-family: 'JetBrains Mono', monospace; }
    .duel-turn-banner {
      background: linear-gradient(135deg, rgba(236, 72, 153, 0.2), rgba(139, 92, 246, 0.2));
      border: 1px solid var(--primary); border-radius: 14px; padding: 14px; text-align: center;
    }

    /* Leaderboard Table */
    .leaderboard-table { width: 100%; border-collapse: collapse; font-size: 13px; }
    .leaderboard-table th {
      text-align: left; padding: 10px 12px; color: var(--text-muted); font-size: 11px;
      text-transform: uppercase; border-bottom: 1px solid var(--card-border);
    }
    .leaderboard-table td {
      padding: 12px; border-bottom: 1px solid rgba(255, 255, 255, 0.04); font-weight: 600;
    }
    .rank-cell { font-family: 'JetBrains Mono', monospace; font-weight: 800; color: var(--primary); width: 40px; }
    .player-cell { font-weight: 700; color: #fff; display: flex; align-items: center; gap: 6px; }

    /* Footer */
    .footer-actions { display: flex; gap: 10px; }
    .action-btn {
      flex: 1; padding: 12px 16px; border-radius: 14px; font-size: 13px; font-weight: 800;
      cursor: pointer; display: flex; align-items: center; justify-content: center; gap: 6px;
      border: none;
    }
    .btn-replay { background: linear-gradient(135deg, var(--primary), var(--accent)); color: #fff; }
    .btn-rules { background: rgba(255, 255, 255, 0.06); color: var(--text-main); border: 1px solid var(--card-border); }
  </style>
</head>
<body data-theme="cosmic">

  <div class="bg-watermark-container">
    <div class="bg-watermark-title">NUMBER GUESSING GAME</div>
    <div class="bg-watermark-subtitle">NEO-GUESS // ARCADE EDITION</div>
  </div>

  <canvas id="ambientCanvas"></canvas>
  <canvas id="confettiCanvas"></canvas>

  <div class="app-container">
    <!-- Mode Switcher Tabs -->
    <div class="mode-nav">
      <button class="mode-tab active" id="tabSolo" onclick="switchMode('solo')">
        <span>🕹️ Solo Arcade</span>
      </button>
      <button class="mode-tab" id="tabDuel" onclick="switchMode('duel')">
        <span>⚔️ 2-Player Duel</span>
      </button>
      <button class="mode-tab" id="tabLeaderboard" onclick="switchMode('leaderboard')">
        <span>🏆 Leaderboard</span>
      </button>
    </div>

    <!-- Header -->
    <div class="card header">
      <div class="brand">
        <span style="font-size: 24px;">🎯</span>
        <h1>NEO-GUESS</h1>
      </div>
      <div class="header-controls">
        <div class="player-profile-pill" onclick="changePlayerName()">
          <span id="playerIcon">👤</span>
          <span id="playerNameDisplay">Player 1</span> ✏️
        </div>
        <button class="control-btn" id="themeBtn" onclick="cycleTheme()">🎨</button>
        <button class="control-btn" id="audioToggleBtn" onclick="toggleAudio()">🔊</button>
      </div>
    </div>

    <!-- SOLO MODE VIEW -->
    <div id="soloView">
      <!-- Stats -->
      <div class="card stats-bar">
        <div class="stat-item"><div class="stat-label">Wins</div><div class="stat-val" id="statWins">0</div></div>
        <div class="stat-item"><div class="stat-label">Win Rate</div><div class="stat-val" id="statRate">0%</div></div>
        <div class="stat-item"><div class="stat-label">Streak</div><div class="stat-val" id="statStreak">0 🔥</div></div>
        <div class="stat-item"><div class="stat-label">High Score</div><div class="stat-val" id="statHighScore">0 ⭐</div></div>
        <div class="stat-item"><div class="stat-label">Total Pts</div><div class="stat-val" id="statTotalScore">0</div></div>
      </div>

      <!-- Difficulty & Timer -->
      <div class="card diff-container" style="margin-top: 14px;">
        <div class="diff-header">
          <span class="diff-label">DIFFICULTY PRESET</span>
          <div style="display: flex; align-items: center; gap: 8px;">
            <div class="timer-pill" id="roundTimer">⏱️ 0.0s</div>
            <span class="diff-label" id="attemptsText">Attempts: 7 / 7</span>
          </div>
        </div>
        <div class="diff-pills">
          <button class="diff-btn" onclick="selectDifficulty('EASY')">Easy (1-50)</button>
          <button class="diff-btn active" onclick="selectDifficulty('MEDIUM')">Med (1-100)</button>
          <button class="diff-btn" onclick="selectDifficulty('HARD')">Hard (1-500)</button>
          <button class="diff-btn" onclick="selectDifficulty('EXPERT')">Exp (1-1000)</button>
        </div>
        <div class="attempts-wrapper">
          <span class="diff-label">ENERGY SHIELD:</span>
          <div class="gauge-dots" id="gaugeDots"></div>
        </div>
      </div>

      <!-- Thermal Proximity -->
      <div class="card thermal-box" style="margin-top: 14px;">
        <span class="thermal-title">Thermal Proximity:</span>
        <div class="thermal-status" id="thermalStatus">
          <span>📡 Awaiting first guess...</span>
        </div>
      </div>

      <!-- Dynamic Range Visualizer -->
      <div class="card range-box" style="margin-top: 14px;">
        <div class="range-labels">
          <span id="labelTotalMin">1</span>
          <span id="labelTotalMax">100</span>
        </div>
        <div class="range-track">
          <div class="range-active" id="rangeActiveBar" style="left: 0%; width: 100%;"></div>
        </div>
        <div class="active-zone-badge">
          Active Search Zone: <span id="activeZoneText">[1 ... 100]</span>
        </div>
      </div>

      <!-- Tactical Hints -->
      <div class="card lifelines-row" style="margin-top: 14px;">
        <button class="hint-btn" onclick="askHint('parity')">⚖️ Even / Odd Clue</button>
        <button class="hint-btn" onclick="askHint('divisibility')">🔍 Divisibility Clue</button>
      </div>

      <!-- Input Card -->
      <div class="card input-card" style="margin-top: 14px;">
        <div class="input-row">
          <input type="number" id="guessInput" class="guess-input" placeholder="?" autocomplete="off" autofocus>
          <button id="submitBtn" class="guess-btn" onclick="submitGuess()">SUBMIT 🎯</button>
        </div>
        <div class="feedback-banner" id="feedbackBanner">
          <div class="feedback-title" id="feedbackTitle">Ready to Play!</div>
          <div class="feedback-sub" id="feedbackSub">Enter your prediction above.</div>
        </div>
      </div>

      <!-- Guess History -->
      <div class="card history-card" style="margin-top: 14px;">
        <div class="diff-label">Guess History</div>
        <div class="chips-flow" id="chipsFlow">
          <span style="font-size: 13px; color: var(--text-muted); align-self: center;">No guesses yet in this round.</span>
        </div>
      </div>

      <!-- Footer Actions -->
      <div class="footer-actions" style="margin-top: 14px;">
        <button class="action-btn btn-replay" id="replayBtn" onclick="startNewRound()">NEW ROUND 🔄</button>
        <button class="action-btn btn-rules" onclick="showRules()">HOW TO PLAY ℹ️</button>
      </div>
    </div>

    <!-- 2-PLAYER DUEL VIEW -->
    <div id="duelView" style="display: none;">
      <!-- Duel Setup -->
      <div class="card duel-setup-box" id="duelSetupCard">
        <div class="diff-label">⚔️ 2-PLAYER SPEED COMPETITION SETUP</div>
        <p style="font-size: 13px; color: var(--text-muted);">
          Two players compete on the same secret code. Whoever completes it <b>fastest</b> with fewest attempts is the winner!
        </p>
        <div class="duel-inputs">
          <div class="duel-input-group">
            <label>Player 1 Name</label>
            <input type="text" id="duelP1Name" class="duel-name-input" value="Player 1">
          </div>
          <div class="duel-input-group">
            <label>Player 2 Name</label>
            <input type="text" id="duelP2Name" class="duel-name-input" value="Player 2">
          </div>
        </div>
        <button class="duel-start-btn" onclick="startDuelMatch()">START SPEED DUEL 🏁</button>
      </div>

      <!-- Active Duel Arena -->
      <div id="duelActiveCard" style="display: none; flex-direction: column; gap: 14px;">
        <div class="duel-hud">
          <div class="hud-player" id="hudP1">
            <div class="hud-name">🔴 <span id="duelHudP1Name">P1</span></div>
            <div class="hud-stats" id="duelHudP1Stats">Ready...</div>
          </div>
          <div class="hud-player" id="hudP2">
            <div class="hud-name">🔵 <span id="duelHudP2Name">P2</span></div>
            <div class="hud-stats" id="duelHudP2Stats">Waiting for turn...</div>
          </div>
        </div>

        <!-- Duel Turn Notification -->
        <div class="duel-turn-banner" id="duelTurnBanner">
          <h3 id="duelTurnTitle">🔴 Player 1's Turn</h3>
          <p id="duelTurnSub" style="font-size: 13px; color: var(--text-muted); margin-top: 4px;">Timer is ticking! Guess fast to secure the win.</p>
        </div>

        <!-- Duel Range & Attempts -->
        <div class="card range-box">
          <div class="range-labels">
            <span id="duelMin">1</span>
            <span id="duelMax">100</span>
          </div>
          <div class="range-track">
            <div class="range-active" id="duelRangeBar" style="left: 0%; width: 100%;"></div>
          </div>
          <div class="active-zone-badge">
            Search Zone: <span id="duelZoneText">[1 ... 100]</span> | <span id="duelAttemptsText">Attempts: 7 / 7</span>
          </div>
        </div>

        <!-- Duel Guess Input -->
        <div class="card input-card">
          <div class="input-row">
            <input type="number" id="duelGuessInput" class="guess-input" placeholder="?" autocomplete="off">
            <button id="duelSubmitBtn" class="guess-btn" onclick="submitDuelGuess()">SUBMIT 🎯</button>
          </div>
          <div class="feedback-banner" id="duelFeedbackBanner">
            <div class="feedback-title" id="duelFeedbackTitle">Your turn!</div>
            <div class="feedback-sub" id="duelFeedbackSub">Find the secret number faster than your opponent!</div>
          </div>
        </div>

        <!-- Intermission Card -->
        <div class="card" id="duelIntermissionCard" style="display: none; text-align: center;">
          <h2 style="color: var(--primary);">🏁 PLAYER 1 HAS FINISHED!</h2>
          <p id="duelIntermissionText" style="margin: 10px 0; color: var(--text-muted); font-size: 14px;"></p>
          <button class="duel-start-btn" onclick="startPlayer2Turn()" style="margin-top: 8px;">
            HAND OVER & START PLAYER 2 TURN 🔵
          </button>
        </div>

        <!-- Victory Modal Card -->
        <div class="card" id="duelVictoryCard" style="display: none; text-align: center;">
          <h1 id="duelWinnerTitle" style="color: #10b981; font-size: 26px;">👑 WINNER ANNOUNCED!</h1>
          <p id="duelVictorySummary" style="font-size: 15px; margin: 12px 0; line-height: 1.4; color: #fff;"></p>
          <button class="duel-start-btn" onclick="resetDuelMatch()" style="margin-top: 10px;">REMATCH ⚔️</button>
        </div>
      </div>
    </div>

    <!-- LEADERBOARD VIEW -->
    <div id="leaderboardView" style="display: none;">
      <div class="card">
        <div class="diff-header" style="margin-bottom: 12px;">
          <span class="diff-label">🏆 HALL OF FAME // TOP PLAYERS</span>
          <span style="font-size: 12px; color: var(--text-muted);">Ranked by Score & Speed</span>
        </div>
        <table class="leaderboard-table">
          <thead>
            <tr>
              <th>Rank</th>
              <th>Player</th>
              <th>Score</th>
              <th>Guesses</th>
              <th>Time</th>
              <th>Diff</th>
            </tr>
          </thead>
          <tbody id="leaderboardBody">
            <tr><td colspan="6" style="text-align: center; color: var(--text-muted);">Loading scores...</td></tr>
          </tbody>
        </table>
      </div>
    </div>
  </div>

  <script>
    // State
    let currentMode = 'solo';
    let currentPlayerName = localStorage.getItem('neoGuessPlayerName') || 'Player 1';
    let currentDifficulty = 'MEDIUM';
    let soundEnabled = true;
    let audioCtx = null;
    let roundStartTime = Date.now();
    let timerInterval = null;

    document.getElementById('playerNameDisplay').textContent = currentPlayerName;
    document.getElementById('duelP1Name').value = currentPlayerName;

    function changePlayerName() {
      const name = prompt("Enter your Player Name / Alias:", currentPlayerName);
      if (name && name.trim()) {
        currentPlayerName = name.trim();
        localStorage.setItem('neoGuessPlayerName', currentPlayerName);
        document.getElementById('playerNameDisplay').textContent = currentPlayerName;
        document.getElementById('duelP1Name').value = currentPlayerName;
      }
    }

    // Navigation Switcher
    function switchMode(mode) {
      currentMode = mode;
      document.querySelectorAll('.mode-tab').forEach(t => t.classList.remove('active'));
      document.getElementById('soloView').style.display = (mode === 'solo') ? 'block' : 'none';
      document.getElementById('duelView').style.display = (mode === 'duel') ? 'block' : 'none';
      document.getElementById('leaderboardView').style.display = (mode === 'leaderboard') ? 'block' : 'none';

      if (mode === 'solo') document.getElementById('tabSolo').classList.add('active');
      if (mode === 'duel') {
        document.getElementById('tabDuel').classList.add('active');
        fetchDuelState();
      }
      if (mode === 'leaderboard') {
        document.getElementById('tabLeaderboard').classList.add('active');
        fetchLeaderboard();
      }
      playTone(550, 'sine', 0.08);
    }

    // Theme Switcher
    const themes = ['cosmic', 'emerald', 'sunset'];
    let currentThemeIdx = 0;
    function cycleTheme() {
      currentThemeIdx = (currentThemeIdx + 1) % themes.length;
      document.body.setAttribute('data-theme', themes[currentThemeIdx]);
      playTone(600, 'sine', 0.08);
    }

    // Audio Synthesizer
    function getAudioContext() {
      if (!audioCtx) audioCtx = new (window.AudioContext || window.webkitAudioContext)();
      if (audioCtx.state === 'suspended') audioCtx.resume();
      return audioCtx;
    }
    function playTone(freq, type = 'sine', duration = 0.15) {
      if (!soundEnabled) return;
      try {
        const ctx = getAudioContext();
        const osc = ctx.createOscillator();
        const gain = ctx.createGain();
        osc.type = type;
        osc.frequency.setValueAtTime(freq, ctx.currentTime);
        gain.gain.setValueAtTime(0.12, ctx.currentTime);
        gain.gain.exponentialRampToValueAtTime(0.0001, ctx.currentTime + duration);
        osc.connect(gain); gain.connect(ctx.destination);
        osc.start(); osc.stop(ctx.currentTime + duration);
      } catch(e) {}
    }
    function toggleAudio() {
      soundEnabled = !soundEnabled;
      document.getElementById('audioToggleBtn').textContent = soundEnabled ? '🔊' : '🔇';
    }

    // Confetti
    const cCanvas = document.getElementById('confettiCanvas');
    const cCtx = cCanvas.getContext('2d');
    let confetti = [], cTimer = null;
    function resizeConfetti() { cCanvas.width = window.innerWidth; cCanvas.height = window.innerHeight; }
    window.addEventListener('resize', resizeConfetti);
    resizeConfetti();

    function triggerConfetti() {
      confetti = [];
      const colors = ['#ec4899', '#8b5cf6', '#06b6d4', '#10b981', '#f59e0b'];
      for (let i = 0; i < 110; i++) {
        confetti.push({
          x: Math.random() * cCanvas.width, y: -20 - Math.random() * 200,
          vx: (Math.random() - 0.5) * 4.5, vy: 2.5 + Math.random() * 5.5,
          color: colors[Math.floor(Math.random() * colors.length)],
          w: 8 + Math.random() * 8, h: 10 + Math.random() * 10,
          rot: Math.random() * 360, rotSpeed: (Math.random() - 0.5) * 12
        });
      }
      if (cTimer) cancelAnimationFrame(cTimer);
      const st = Date.now();
      function update() {
        cCtx.clearRect(0, 0, cCanvas.width, cCanvas.height);
        let active = false;
        confetti.forEach(p => {
          p.x += p.vx; p.y += p.vy; p.rot += p.rotSpeed;
          if (p.y < cCanvas.height + 40) active = true;
          cCtx.save(); cCtx.translate(p.x, p.y); cCtx.rotate((p.rot * Math.PI) / 180);
          cCtx.fillStyle = p.color; cCtx.fillRect(-p.w / 2, -p.h / 2, p.w, p.h); cCtx.restore();
        });
        if (active && Date.now() - st < 4500) cTimer = requestAnimationFrame(update);
        else cCtx.clearRect(0, 0, cCanvas.width, cCanvas.height);
      }
      update();
    }

    // Starfield Background
    const aCanvas = document.getElementById('ambientCanvas');
    const aCtx = aCanvas.getContext('2d');
    let stars = [];
    function resizeAmb() {
      aCanvas.width = window.innerWidth; aCanvas.height = window.innerHeight;
      stars = [];
      for (let i = 0; i < 65; i++) {
        stars.push({ x: Math.random() * aCanvas.width, y: Math.random() * aCanvas.height, r: Math.random() * 1.6 + 0.4, speed: Math.random() * 0.4 + 0.1 });
      }
    }
    window.addEventListener('resize', resizeAmb);
    resizeAmb();
    function animateStars() {
      aCtx.clearRect(0, 0, aCanvas.width, aCanvas.height);
      stars.forEach(s => {
        s.y -= s.speed; if (s.y < 0) s.y = aCanvas.height;
        aCtx.beginPath(); aCtx.arc(s.x, s.y, s.r, 0, Math.PI * 2);
        aCtx.fillStyle = 'rgba(255, 255, 255, 0.5)'; aCtx.fill();
      });
      requestAnimationFrame(animateStars);
    }
    animateStars();

    // Solo Mechanics
    function startTimer() {
      if (timerInterval) clearInterval(timerInterval);
      roundStartTime = Date.now();
      timerInterval = setInterval(() => {
        const el = ((Date.now() - roundStartTime) / 1000).toFixed(1);
        document.getElementById('roundTimer').textContent = `⏱️ ${el}s`;
      }, 100);
    }
    function stopTimer() { if (timerInterval) clearInterval(timerInterval); }

    async function fetchState() {
      try {
        const res = await fetch('/api/state');
        const data = await res.json();
        renderSolo(data);
      } catch (e) {}
    }

    async function selectDifficulty(diff) {
      currentDifficulty = diff;
      document.querySelectorAll('.diff-btn').forEach(b => b.classList.toggle('active', b.textContent.toUpperCase().includes(diff.slice(0, 3))));
      await startNewRound();
    }

    async function startNewRound() {
      startTimer();
      const res = await fetch('/api/new-game', {
        method: 'POST', headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ difficulty: currentDifficulty })
      });
      const data = await res.json();
      renderSolo(data);
      const input = document.getElementById('guessInput');
      input.value = ''; input.disabled = false;
      document.getElementById('submitBtn').disabled = false;
      document.getElementById('replayBtn').textContent = 'NEW ROUND 🔄';
      document.getElementById('thermalStatus').innerHTML = '<span>📡 Awaiting first guess...</span>';
      input.focus();
    }

    async function submitGuess() {
      const input = document.getElementById('guessInput');
      const val = parseInt(input.value.trim(), 10);
      if (isNaN(val)) { input.focus(); return; }

      const res = await fetch('/api/guess', {
        method: 'POST', headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ guess: val })
      });
      const data = await res.json();
      renderSolo(data);
      input.value = '';
      if (!data.isFinished) input.focus();
      else {
        stopTimer();
        if (data.isWon) {
          const elTime = parseFloat(((Date.now() - roundStartTime) / 1000).toFixed(1));
          submitLeaderboardScore(currentPlayerName, data.lastResult.scoreEarned, data.attemptsUsed, elTime, currentDifficulty);
        }
      }
    }

    async function askHint(type) {
      const res = await fetch('/api/hint', {
        method: 'POST', headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ type: type })
      });
      const data = await res.json();
      document.getElementById('feedbackSub').textContent = data.hint;
      document.getElementById('feedbackSub').style.color = '#38bdf8';
    }

    document.getElementById('guessInput').addEventListener('keydown', e => { if (e.key === 'Enter') submitGuess(); });

    function renderSolo(data) {
      document.getElementById('labelTotalMin').textContent = data.min;
      document.getElementById('labelTotalMax').textContent = data.max;
      document.getElementById('activeZoneText').textContent = `[${data.narrowedMin} ... ${data.narrowedMax}]`;

      const span = Math.max(1, data.max - data.min);
      const leftP = ((data.narrowedMin - data.min) / span) * 100;
      const widthP = Math.max(2, ((data.narrowedMax - data.narrowedMin) / span) * 100);
      document.getElementById('rangeActiveBar').style.left = `${leftP}%`;
      document.getElementById('rangeActiveBar').style.width = `${widthP}%`;

      document.getElementById('attemptsText').textContent = `Attempts: ${data.remainingAttempts} / ${data.maxAttempts}`;
      const dots = document.getElementById('gaugeDots');
      dots.innerHTML = '';
      for (let i = 0; i < data.maxAttempts; i++) {
        const d = document.createElement('div');
        d.className = 'dot' + (i < data.remainingAttempts ? ' filled' : '');
        dots.appendChild(d);
      }

      if (data.stats) {
        document.getElementById('statWins').textContent = data.stats.gamesWon;
        document.getElementById('statRate').textContent = `${Math.round(data.stats.winRate)}%`;
        document.getElementById('statStreak').textContent = `${data.stats.currentStreak} 🔥`;
        document.getElementById('statHighScore').textContent = `${data.stats.highScore} ⭐`;
        document.getElementById('statTotalScore').textContent = data.stats.totalScore;
      }

      const chips = document.getElementById('chipsFlow');
      if (data.history && data.history.length > 0) {
        chips.innerHTML = '';
        data.history.forEach(h => {
          const c = document.createElement('div');
          c.className = 'chip ' + (h.status === 'TOO_HIGH' ? 'high' : h.status === 'TOO_LOW' ? 'low' : h.status === 'CORRECT' ? 'correct' : 'over');
          c.innerHTML = `${h.guess} ` + (h.status === 'TOO_HIGH' ? '🔻' : h.status === 'TOO_LOW' ? '🔺' : h.status === 'CORRECT' ? '🎯' : '✕');
          chips.appendChild(c);
        });
      }

      const banner = document.getElementById('feedbackBanner');
      const title = document.getElementById('feedbackTitle');
      const sub = document.getElementById('feedbackSub');
      banner.className = 'feedback-banner';

      if (data.lastResult) {
        const lr = data.lastResult;
        if (lr.proximityDesc) document.getElementById('thermalStatus').innerHTML = `<span>${lr.proximityDesc}</span>`;

        if (lr.status === 'CORRECT') {
          banner.classList.add('success');
          title.textContent = '🎉 BULLSEYE! YOU WON!';
          sub.textContent = `Secret number was ${lr.revealedTarget}. Solved in ${data.attemptsUsed} attempts (+${lr.scoreEarned} pts)!`;
          triggerConfetti();
          document.getElementById('guessInput').disabled = true;
          document.getElementById('submitBtn').disabled = true;
          document.getElementById('replayBtn').textContent = 'PLAY AGAIN 🎮';
        } else if (lr.status === 'GAME_OVER') {
          banner.classList.add('danger');
          title.textContent = '💀 OUT OF ATTEMPTS!';
          sub.textContent = `Secret number was ${lr.revealedTarget}. Click 'Play Again' to retry.`;
          document.getElementById('guessInput').disabled = true;
          document.getElementById('submitBtn').disabled = true;
          document.getElementById('replayBtn').textContent = 'PLAY AGAIN 🎮';
        } else if (lr.status === 'TOO_HIGH') {
          banner.classList.add('too-high');
          title.textContent = `🔻 TOO HIGH! (${lr.guess})`;
          sub.textContent = `Target is lower! Zone: [${data.narrowedMin} ... ${data.narrowedMax}].`;
        } else if (lr.status === 'TOO_LOW') {
          banner.classList.add('too-low');
          title.textContent = `🔺 TOO LOW! (${lr.guess})`;
          sub.textContent = `Target is higher! Zone: [${data.narrowedMin} ... ${data.narrowedMax}].`;
        }
      }
    }

    // 2-Player Duel Mechanics
    async function startDuelMatch() {
      const p1 = document.getElementById('duelP1Name').value.trim() || 'Player 1';
      const p2 = document.getElementById('duelP2Name').value.trim() || 'Player 2';
      const res = await fetch('/api/duel/start', {
        method: 'POST', headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ p1Name: p1, p2Name: p2, difficulty: currentDifficulty })
      });
      const data = await res.json();
      document.getElementById('duelSetupCard').style.display = 'none';
      document.getElementById('duelActiveCard').style.display = 'flex';
      renderDuel(data);
    }

    async function fetchDuelState() {
      const res = await fetch('/api/duel/state');
      const data = await res.json();
      if (data.active) {
        document.getElementById('duelSetupCard').style.display = 'none';
        document.getElementById('duelActiveCard').style.display = 'flex';
        renderDuel(data);
      } else {
        document.getElementById('duelSetupCard').style.display = 'flex';
        document.getElementById('duelActiveCard').style.display = 'none';
      }
    }

    async function submitDuelGuess() {
      const inp = document.getElementById('duelGuessInput');
      const val = parseInt(inp.value.trim(), 10);
      if (isNaN(val)) return;

      const res = await fetch('/api/duel/guess', {
        method: 'POST', headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ guess: val })
      });
      const data = await res.json();
      inp.value = '';
      renderDuel(data);
    }

    async function startPlayer2Turn() {
      const res = await fetch('/api/duel/p2-start', { method: 'POST' });
      const data = await res.json();
      renderDuel(data);
    }

    function resetDuelMatch() {
      document.getElementById('duelSetupCard').style.display = 'flex';
      document.getElementById('duelActiveCard').style.display = 'none';
      document.getElementById('duelVictoryCard').style.display = 'none';
    }

    document.getElementById('duelGuessInput').addEventListener('keydown', e => { if (e.key === 'Enter') submitDuelGuess(); });

    function renderDuel(data) {
      document.getElementById('duelHudP1Name').textContent = data.p1Name;
      document.getElementById('duelHudP2Name').textContent = data.p2Name;

      document.getElementById('hudP1').classList.toggle('active', data.phase === 'PLAYER1_TURN');
      document.getElementById('hudP2').classList.toggle('active', data.phase === 'PLAYER2_TURN');

      document.getElementById('duelMin').textContent = data.min;
      document.getElementById('duelMax').textContent = data.max;
      document.getElementById('duelZoneText').textContent = `[${data.narrowedMin} ... ${data.narrowedMax}]`;
      document.getElementById('duelAttemptsText').textContent = `Attempts: ${data.remainingAttempts} / ${data.maxAttempts}`;

      const span = Math.max(1, data.max - data.min);
      const lp = ((data.narrowedMin - data.min) / span) * 100;
      const wp = Math.max(2, ((data.narrowedMax - data.narrowedMin) / span) * 100);
      document.getElementById('duelRangeBar').style.left = `${lp}%`;
      document.getElementById('duelRangeBar').style.width = `${wp}%`;

      if (data.phase === 'PLAYER1_TURN') {
        document.getElementById('duelTurnBanner').style.display = 'block';
        document.getElementById('duelTurnTitle').textContent = `🔴 ${data.p1Name}'s Turn`;
        document.getElementById('duelTurnSub').textContent = 'Solve as fast as possible to set a challenging target!';
        document.getElementById('duelIntermissionCard').style.display = 'none';
        document.getElementById('duelVictoryCard').style.display = 'none';
        document.getElementById('duelGuessInput').disabled = false;
        document.getElementById('duelSubmitBtn').disabled = false;
        document.getElementById('duelGuessInput').focus();
      } else if (data.phase === 'INTERMISSION') {
        document.getElementById('duelTurnBanner').style.display = 'none';
        document.getElementById('duelIntermissionCard').style.display = 'block';
        document.getElementById('duelIntermissionText').textContent =
          `${data.p1Name} finished in ${data.p1Attempts} guesses and ${data.p1Time.toFixed(1)}s! Hand the device over to ${data.p2Name}.`;
        document.getElementById('duelGuessInput').disabled = true;
        document.getElementById('duelSubmitBtn').disabled = true;
      } else if (data.phase === 'PLAYER2_TURN') {
        document.getElementById('duelIntermissionCard').style.display = 'none';
        document.getElementById('duelTurnBanner').style.display = 'block';
        document.getElementById('duelTurnTitle').textContent = `🔵 ${data.p2Name}'s Turn`;
        document.getElementById('duelTurnSub').textContent = `Beat ${data.p1Name}'s score/speed! Target time: ${data.p1Time.toFixed(1)}s.`;
        document.getElementById('duelGuessInput').disabled = false;
        document.getElementById('duelSubmitBtn').disabled = false;
        document.getElementById('duelGuessInput').focus();
      } else if (data.phase === 'COMPLETED') {
        document.getElementById('duelTurnBanner').style.display = 'none';
        document.getElementById('duelVictoryCard').style.display = 'block';
        document.getElementById('duelWinnerTitle').textContent = `👑 ${data.winner}`;
        document.getElementById('duelVictorySummary').textContent = data.victorySummary;
        document.getElementById('duelGuessInput').disabled = true;
        document.getElementById('duelSubmitBtn').disabled = true;
        triggerConfetti();
      }

      if (data.lastResult) {
        const banner = document.getElementById('duelFeedbackBanner');
        banner.className = 'feedback-banner';
        if (data.lastResult.status === 'TOO_HIGH') {
          banner.classList.add('too-high');
          document.getElementById('duelFeedbackTitle').textContent = `🔻 TOO HIGH! (${data.lastResult.guess})`;
        } else if (data.lastResult.status === 'TOO_LOW') {
          banner.classList.add('too-low');
          document.getElementById('duelFeedbackTitle').textContent = `🔺 TOO LOW! (${data.lastResult.guess})`;
        } else if (data.lastResult.status === 'CORRECT') {
          banner.classList.add('success');
          document.getElementById('duelFeedbackTitle').textContent = '🎉 CORRECT!';
        }
      }
    }

    // Leaderboard Mechanics
    async function fetchLeaderboard() {
      try {
        const res = await fetch('/api/leaderboard');
        const data = await res.json();
        const tbody = document.getElementById('leaderboardBody');
        tbody.innerHTML = '';
        if (data.entries && data.entries.length > 0) {
          data.entries.forEach(e => {
            const tr = document.createElement('tr');
            const medal = e.rank === 1 ? '🥇' : e.rank === 2 ? '🥈' : e.rank === 3 ? '🥉' : `#${e.rank}`;
            tr.innerHTML = `
              <td class="rank-cell">${medal}</td>
              <td class="player-cell">${e.name}</td>
              <td style="color: var(--primary); font-family: 'JetBrains Mono';">${e.score}</td>
              <td style="font-family: 'JetBrains Mono';">${e.attempts}</td>
              <td style="color: var(--secondary); font-family: 'JetBrains Mono';">${e.timeSeconds}s</td>
              <td><span style="font-size: 11px; background: rgba(255,255,255,0.08); padding: 2px 6px; border-radius: 6px;">${e.difficulty}</span></td>
            `;
            tbody.appendChild(tr);
          });
        } else {
          tbody.innerHTML = '<tr><td colspan="6" style="text-align: center; color: var(--text-muted);">No high scores recorded yet!</td></tr>';
        }
      } catch (err) {}
    }

    async function submitLeaderboardScore(name, score, attempts, time, diff) {
      try {
        await fetch('/api/leaderboard', {
          method: 'POST', headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({ playerName: name, score: score, attempts: attempts, timeSeconds: time, difficulty: diff })
        });
      } catch (err) {}
    }

    function showRules() {
      alert("🎮 HOW TO PLAY NEO-GUESS\\n\\n1. Solo Arcade: Guess the secret code before attempts expire and set the leaderboard record!\\n2. 2-Player Duel: Two players take turns solving the same secret code. Whoever completes it fastest wins!\\n3. Hall of Fame: Track your high scores and speedrun times.");
    }

    // Init
    startTimer();
    fetchState();
  </script>
</body>
</html>
""";
    }
}
