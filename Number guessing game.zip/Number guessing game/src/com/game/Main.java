package com.game;

import com.game.cli.AestheticCli;
import com.game.gui.ModernGameFrame;

import javax.swing.SwingUtilities;
import javax.swing.UIManager;
import java.awt.GraphicsEnvironment;

/**
 * Application Entry Point.
 * Launches the modern Swing GUI by default, or the stylized CLI if requested
 * via '--cli' argument or in headless environments.
 */
public class Main {

    public static void main(String[] args) {
        boolean forceCli = false;
        boolean launchWeb = false;

        for (String arg : args) {
            if ("--cli".equalsIgnoreCase(arg) || "-c".equalsIgnoreCase(arg)) {
                forceCli = true;
                break;
            }
            if ("--web".equalsIgnoreCase(arg) || "-w".equalsIgnoreCase(arg)) {
                launchWeb = true;
                break;
            }
        }

        // Web Browser Mode
        if (launchWeb) {
            com.game.web.GameWebServer.startAndOpen(8080);
            return;
        }

        // If forced to CLI or if running in headless terminal environment
        if (forceCli || GraphicsEnvironment.isHeadless()) {
            new AestheticCli().start();
            return;
        }

        // Launch Modern Aesthetic GUI
        SwingUtilities.invokeLater(() -> {
            try {
                // Apply system look and feel for native window decorations
                UIManager.setLookAndFeel(UIManager.getSystemLookAndFeelClassName());
            } catch (Exception ignored) {
                // Keep default styling
            }

            ModernGameFrame frame = new ModernGameFrame();
            frame.setVisible(true);
        });
    }
}
