@echo off
setlocal
title Packaging NEO-GUESS JAR

echo [NEO-GUESS] Preparing build directories...
if not exist "bin" mkdir bin

echo [NEO-GUESS] Compiling all sources...
javac -encoding UTF-8 -d bin src\com\game\model\*.java src\com\game\audio\*.java src\com\game\gui\*.java src\com\game\cli\*.java src\com\game\web\*.java src\com\game\Main.java
if %ERRORLEVEL% neq 0 (
    echo [ERROR] Compilation failed!
    pause
    exit /b %ERRORLEVEL%
)

echo Main-Class: com.game.Main> Manifest.txt
echo [NEO-GUESS] Creating NumberGuessingGame.jar...
jar cfm NumberGuessingGame.jar Manifest.txt -C bin .
del Manifest.txt

if %ERRORLEVEL% equ 0 (
    echo [SUCCESS] Standalone executable created: NumberGuessingGame.jar
    echo You can run it anytime with: java -jar NumberGuessingGame.jar or by double clicking!
) else (
    echo [ERROR] Failed to package JAR.
)
pause
