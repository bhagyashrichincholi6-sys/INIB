@echo off
setlocal
title NEO-GUESS Launcher

echo [NEO-GUESS] Checking Java installation...
where java >nul 2>&1
if %ERRORLEVEL% neq 0 (
    echo [ERROR] Java is not installed or not in PATH! Please install JDK 17 or higher.
    pause
    exit /b 1
)

if not exist "bin" mkdir bin

echo [NEO-GUESS] Compiling sources...
javac -encoding UTF-8 -d bin src\com\game\model\*.java src\com\game\audio\*.java src\com\game\gui\*.java src\com\game\cli\*.java src\com\game\Main.java
if %ERRORLEVEL% neq 0 (
    echo [ERROR] Compilation failed!
    pause
    exit /b %ERRORLEVEL%
)

echo [NEO-GUESS] Launching Modern GUI...
start javaw -cp bin com.game.Main
exit /b 0
