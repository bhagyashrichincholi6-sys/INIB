@echo off
setlocal
title NEO-GUESS Terminal Game

if not exist "bin" mkdir bin

echo [NEO-GUESS] Compiling sources...
javac -encoding UTF-8 -d bin src\com\game\model\*.java src\com\game\audio\*.java src\com\game\gui\*.java src\com\game\cli\*.java src\com\game\Main.java
if %ERRORLEVEL% neq 0 (
    echo [ERROR] Compilation failed!
    pause
    exit /b %ERRORLEVEL%
)

echo [NEO-GUESS] Launching Terminal Interface...
java -cp bin com.game.Main --cli
pause
