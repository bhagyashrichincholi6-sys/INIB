# 🎯 NEO-GUESS // Precision Number Guessing Game (Java 21)

An aesthetic, modern, and engaging implementation of the **Number Guessing Game** built in pure Java. Designed with a dark glassmorphic UI, real-time narrowing range visualizer, procedural MIDI sound effects, confetti celebrations, difficulty presets, and session statistics.

---

## 📸 Task Requirements & Implementation

This project addresses all five requirements from **Task-1 (Number Guessing Game)**:

| # | Task Requirement | Implementation Feature |
|---|---|---|
| **1** | **Game Setup** (Random number within range) | Selectable difficulties (`Easy`: 1–50, `Medium`: 1–100, `Hard`: 1–500, `Expert`: 1–1000). The secret number is securely generated upon each round. |
| **2** | **User Input & Feedback** (Too high / too low) | Real-time visual and audio feedback: `Too High 🔻` (amber card + high chime), `Too Low 🔺` (cyan card + low chime), and a dynamic narrowing search zone slider `[Min ... Max]`. |
| **3** | **Limited Attempts** | Strictly bounded attempts per difficulty (e.g. 7 for Medium, 6 for Hard). Remaining attempts are visualized with an adaptive energy meter and color warnings. |
| **4** | **Win Condition** | Victory celebration with a confetti particle engine, fanfare audio chord, and score computation based on remaining attempts and difficulty multipliers. |
| **5** | **Replay Option** | Seamless "Play Again / New Round" loop with persistent session tracking across rounds (Total Wins, Win Rate %, Current Streak 🔥, Best Score ⭐). |

---

## ✨ Features & Aesthetics

### 🔮 Modern Glassmorphic GUI
- **Dark Theme Palette:** Slate & Midnight Indigo gradients with translucent glass cards (`#1e293b`).
- **Dynamic Search Zone Bar:** Visual slider that automatically narrows lower and upper bounds as you make guesses.
- **Confetti Particle Engine:** Lightweight 60-FPS physics animation celebrating your victories.
- **Tactile Procedural Audio:** Zero-dependency sound effects using Java's built-in `javax.sound.midi` (chimes, clicks, fanfares) with a quick mute toggle.
- **Guess History Chips:** Interactive pills showing every previous guess and its outcome.

### 💻 Stylized ANSI Terminal Mode
- TrueColor ASCII art banner (`NEO-GUESS // v2.0`).
- Color-coded progress bars and attempt gauges (`●●●○○`).
- Ideal for running over SSH or in developer terminals.

### ⚡ Zero External Dependencies
- Built purely on standard **Java SE 21** (`javax.swing`, `java.awt`, `javax.sound.midi`).
- No Maven, Gradle, or third-party JARs required to compile or run.

---

## 🚀 How to Run

- **Web Browser Edition (Active):** Double-click [`run-web.bat`](run-web.bat) or open [http://localhost:8080](http://localhost:8080).
- **GUI Mode (Desktop):** Double-click [`run.bat`](run.bat) or run `./run.ps1` in PowerShell.
- **Terminal CLI Mode:** Double-click [`run-cli.bat`](run-cli.bat) or run `./run.ps1 -Cli`.

### Option 2: Standalone Executable JAR
1. Double-click [`build.bat`](build.bat) to produce `NumberGuessingGame.jar`.
2. Run directly:
   ```cmd
   java -jar NumberGuessingGame.jar --web     # Opens in browser
   java -jar NumberGuessingGame.jar           # Desktop GUI
   java -jar NumberGuessingGame.jar --cli     # Terminal CLI
   ```

### Option 3: Manual Compilation
```cmd
javac -encoding UTF-8 -d bin src/com/game/model/*.java src/com/game/audio/*.java src/com/game/gui/*.java src/com/game/cli/*.java src/com/game/Main.java
java -cp bin com.game.Main
```

---

## 🧪 Automated Testing

A dedicated test suite is included in `test/com/game/GameEngineTest.java` verifying all 5 core task requirements:
```powershell
javac -encoding UTF-8 -d bin src/com/game/model/*.java test/com/game/*.java
java -cp bin com.game.GameEngineTest
```
Result: **100 tests passed, 0 failures.**

---

## 📁 Project Architecture

```
Number guessing game/
├── src/
│   └── com/
│       └── game/
│           ├── Main.java               # Main entry point (GUI/CLI dispatch)
│           ├── model/
│           │   ├── Difficulty.java     # Difficulty presets, ranges, attempts
│           │   ├── GameEngine.java     # State machine, guess processing, scoring
│           │   └── GameStats.java      # Session metrics, streaks, win rate
│           ├── audio/
│           │   └── SoundManager.java   # Procedural MIDI sound synthesizer
│           ├── gui/
│           │   ├── ModernGameFrame.java# Main dark glassmorphism Swing window
│           │   ├── RangeSliderBar.java # Interactive narrowing range visualizer
│           │   └── ConfettiPanel.java  # Victory particle celebration engine
│           └── cli/
│               └── AestheticCli.java   # ANSI TrueColor terminal interface
├── test/
│   └── com/
│       └── game/
│           └── GameEngineTest.java     # 100-check automated unit test suite
├── run.bat                             # 1-click Windows GUI launcher
├── run-cli.bat                         # 1-click Windows CLI launcher
├── run.ps1                             # PowerShell launcher
├── build.bat                           # Packages executable JAR
├── NumberGuessingGame.jar              # Standalone executable JAR
└── README.md                           # Documentation & user manual
```
