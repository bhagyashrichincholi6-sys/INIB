package com.game.model;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

/**
 * Manages high score records and rankings across players.
 */
public class Leaderboard {
    private static final int MAX_ENTRIES = 20;
    private static Leaderboard instance;
    private final List<LeaderboardEntry> entries = new ArrayList<>();

    public Leaderboard() {
        // Pre-populate with iconic arcade benchmark records
        addEntry(new LeaderboardEntry("NeonPhantom", 1450, 2, 6.8, "MEDIUM", "Oct 11, 14:20"));
        addEntry(new LeaderboardEntry("BinaryWizard", 1120, 3, 9.4, "MEDIUM", "Oct 11, 15:05"));
        addEntry(new LeaderboardEntry("GlitchRacer", 950, 4, 11.2, "EASY", "Oct 11, 16:30"));
    }

    public static synchronized Leaderboard getInstance() {
        if (instance == null) {
            instance = new Leaderboard();
        }
        return instance;
    }

    public synchronized void addEntry(LeaderboardEntry entry) {
        entries.add(entry);
        Collections.sort(entries);
        while (entries.size() > MAX_ENTRIES) {
            entries.remove(entries.size() - 1);
        }
    }

    public synchronized List<LeaderboardEntry> getEntries() {
        return Collections.unmodifiableList(new ArrayList<>(entries));
    }

    public synchronized void clear() {
        entries.clear();
    }
}
