package com.game.gui;

import com.game.audio.SoundManager;
import com.game.model.Difficulty;
import com.game.model.GameEngine;
import com.game.model.GameEngine.GuessRecord;
import com.game.model.GameEngine.GuessResult;
import com.game.model.GameStats;
import com.game.model.Leaderboard;
import com.game.model.LeaderboardEntry;

import javax.swing.BorderFactory;
import javax.swing.Box;
import javax.swing.BoxLayout;
import javax.swing.JButton;
import javax.swing.JComboBox;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JTextField;
import javax.swing.JLayeredPane;
import javax.swing.SwingConstants;
import javax.swing.SwingUtilities;
import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Component;
import java.awt.Cursor;
import java.awt.Dimension;
import java.awt.FlowLayout;
import java.awt.Font;
import java.awt.GradientPaint;
import java.awt.Graphics;
import java.awt.Graphics2D;
import java.awt.GridBagConstraints;
import java.awt.GridBagLayout;
import java.awt.Insets;
import java.awt.RenderingHints;
import java.awt.event.KeyAdapter;
import java.awt.event.KeyEvent;
import java.awt.geom.RoundRectangle2D;
import java.util.ArrayList;
import java.util.List;

/**
 * Modern Dark-Mode GUI with Glassmorphic aesthetic, custom background watermark,
 * thermal proximity meter, tactical hint lifelines, animations, and sound.
 */
public class ModernGameFrame extends JFrame {

    // Aesthetic Cosmic Synthwave Palette
    private static final Color COLOR_BG_TOP = new Color(9, 9, 21);         // Midnight Amethyst
    private static final Color COLOR_BG_BOTTOM = new Color(24, 14, 40);     // Deep Violet Glow
    private static final Color COLOR_CARD = new Color(28, 22, 48, 225);     // Glass Amethyst Card
    private static final Color COLOR_CARD_BORDER = new Color(75, 60, 105);  // Lilac Border
    private static final Color COLOR_PRIMARY = new Color(236, 72, 153);     // Neon Magenta-500
    private static final Color COLOR_PRIMARY_HOVER = new Color(244, 63, 94);
    private static final Color COLOR_ACCENT = new Color(139, 92, 246);      // Electric Violet-500
    private static final Color COLOR_SECONDARY = new Color(6, 182, 212);    // Neon Cyan-500
    private static final Color COLOR_SUCCESS = new Color(16, 185, 129);     // Emerald-500
    private static final Color COLOR_WARNING = new Color(245, 158, 11);     // Amber-500
    private static final Color COLOR_DANGER = new Color(239, 68, 68);       // Rose-500
    private static final Color COLOR_TEXT_MAIN = new Color(248, 250, 252);
    private static final Color COLOR_TEXT_MUTED = new Color(168, 162, 195);

    private final GameEngine engine;
    private final GameStats stats;
    private final SoundManager sound;

    // UI Elements
    private JComboBox<Difficulty> difficultySelector;
    private JLabel attemptsLabel;
    private JLabel streakLabel;
    private JLabel scoreLabel;
    private JLabel winsLabel;
    private JLabel thermalLabel;
    private JTextField guessInputField;
    private JButton submitButton;
    private JButton replayButton;
    private JButton soundToggleButton;
    private JButton playerNameButton;
    private JLabel feedbackMessage;
    private JLabel feedbackSubMessage;
    private JPanel feedbackCard;
    private JPanel historyChipPanel;
    private RangeSliderBar rangeSliderBar;
    private ConfettiPanel confettiPanel;

    private String playerName = "Player 1";
    private long roundStartTime = System.currentTimeMillis();
    private final Leaderboard leaderboard = Leaderboard.getInstance();

    public ModernGameFrame() {
        this.engine = new GameEngine();
        this.stats = new GameStats();
        this.sound = SoundManager.getInstance();

        initializeWindow();
        buildUI();
        startNewGame(Difficulty.MEDIUM);
    }

    private void initializeWindow() {
        setTitle("NEO-GUESS // Precision Number Guessing Game");
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setSize(700, 890);
        setMinimumSize(new Dimension(600, 800));
        setLocationRelativeTo(null);
    }

    private void buildUI() {
        JLayeredPane layeredPane = new JLayeredPane();
        layeredPane.setLayout(null);
        setContentPane(layeredPane);

        // Main background panel with custom watermark painting
        JPanel mainContent = new JPanel() {
            @Override
            protected void paintComponent(Graphics g) {
                super.paintComponent(g);
                Graphics2D g2 = (Graphics2D) g.create();
                g2.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
                g2.setRenderingHint(RenderingHints.KEY_TEXT_ANTIALIASING, RenderingHints.VALUE_TEXT_ANTIALIAS_ON);

                // Deep gradient
                GradientPaint gp = new GradientPaint(
                    0, 0, COLOR_BG_TOP,
                    0, getHeight(), COLOR_BG_BOTTOM
                );
                g2.setPaint(gp);
                g2.fillRect(0, 0, getWidth(), getHeight());

                // Aesthetic Project Name Watermark in Background
                g2.setFont(new Font("Segoe UI", Font.BOLD, 46));
                g2.setColor(new Color(255, 255, 255, 12));
                String watermarkTitle = "NUMBER GUESSING GAME";
                int w1 = g2.getFontMetrics().stringWidth(watermarkTitle);
                g2.drawString(watermarkTitle, (getWidth() - w1) / 2, (getHeight() / 2) - 10);

                g2.setFont(new Font("Segoe UI", Font.BOLD, 20));
                g2.setColor(new Color(236, 72, 153, 24));
                String watermarkSub = "NEO-GUESS // ARCADE EDITION";
                int w2 = g2.getFontMetrics().stringWidth(watermarkSub);
                g2.drawString(watermarkSub, (getWidth() - w2) / 2, (getHeight() / 2) + 30);

                g2.dispose();
            }
        };
        mainContent.setLayout(new BorderLayout());

        // Header Panel
        mainContent.add(createHeaderPanel(), BorderLayout.NORTH);

        // Center Body Panel
        mainContent.add(createBodyPanel(), BorderLayout.CENTER);

        // Footer Panel
        mainContent.add(createFooterPanel(), BorderLayout.SOUTH);

        // Confetti Overlay Layer
        confettiPanel = new ConfettiPanel();

        layeredPane.addComponentListener(new java.awt.event.ComponentAdapter() {
            @Override
            public void componentResized(java.awt.event.ComponentEvent e) {
                Dimension size = layeredPane.getSize();
                mainContent.setBounds(0, 0, size.width, size.height);
                confettiPanel.setBounds(0, 0, size.width, size.height);
                layeredPane.revalidate();
            }
        });

        layeredPane.add(mainContent, Integer.valueOf(1));
        layeredPane.add(confettiPanel, Integer.valueOf(2));
    }

    private JPanel createHeaderPanel() {
        JPanel header = new JPanel();
        header.setOpaque(false);
        header.setLayout(new BoxLayout(header, BoxLayout.Y_AXIS));
        header.setBorder(BorderFactory.createEmptyBorder(18, 24, 10, 24));

        // Top bar
        JPanel topBar = new JPanel(new BorderLayout());
        topBar.setOpaque(false);

        JPanel titleBlock = new JPanel(new FlowLayout(FlowLayout.LEFT, 10, 0));
        titleBlock.setOpaque(false);

        JLabel logoLabel = new JLabel("🎯 NEO-GUESS");
        logoLabel.setFont(new Font("Segoe UI", Font.BOLD, 26));
        logoLabel.setForeground(COLOR_TEXT_MAIN);

        JLabel badgeLabel = new JLabel(" ARCADE v2.5 ");
        badgeLabel.setFont(new Font("Segoe UI", Font.BOLD, 12));
        badgeLabel.setForeground(COLOR_PRIMARY);
        badgeLabel.setOpaque(true);
        badgeLabel.setBackground(new Color(236, 72, 153, 40));
        badgeLabel.setBorder(BorderFactory.createLineBorder(COLOR_PRIMARY, 1, true));

        titleBlock.add(logoLabel);
        titleBlock.add(badgeLabel);

        soundToggleButton = createIconButton("🔊 Sound: ON", e -> {
            sound.toggleSound();
            soundToggleButton.setText(sound.isSoundEnabled() ? "🔊 Sound: ON" : "🔇 Sound: OFF");
            sound.playClick();
        });

        playerNameButton = createIconButton("👤 " + playerName, e -> {
            sound.playClick();
            String input = JOptionPane.showInputDialog(this, "Enter your Player Name / Alias:", playerName);
            if (input != null && !input.trim().isEmpty()) {
                playerName = input.trim();
                playerNameButton.setText("👤 " + playerName);
            }
        });

        JPanel rightControls = new JPanel(new FlowLayout(FlowLayout.RIGHT, 6, 0));
        rightControls.setOpaque(false);
        rightControls.add(playerNameButton);
        rightControls.add(soundToggleButton);

        topBar.add(titleBlock, BorderLayout.WEST);
        topBar.add(rightControls, BorderLayout.EAST);

        header.add(topBar);

        JLabel subtitle = new JLabel("Precision Number Deduction Challenge");
        subtitle.setFont(new Font("Segoe UI", Font.PLAIN, 13));
        subtitle.setForeground(COLOR_TEXT_MUTED);
        subtitle.setBorder(BorderFactory.createEmptyBorder(4, 8, 10, 0));
        header.add(subtitle);

        // Stats Card
        JPanel statsCard = createRoundedCard(new Color(28, 22, 48, 180));
        statsCard.setLayout(new FlowLayout(FlowLayout.CENTER, 24, 6));

        winsLabel = createStatBadge("🏆 Wins: 0");
        streakLabel = createStatBadge("🔥 Streak: 0");
        scoreLabel = createStatBadge("⭐ Score: 0");

        statsCard.add(winsLabel);
        statsCard.add(streakLabel);
        statsCard.add(scoreLabel);

        header.add(statsCard);

        return header;
    }

    private JPanel createBodyPanel() {
        JPanel body = new JPanel();
        body.setOpaque(false);
        body.setLayout(new BoxLayout(body, BoxLayout.Y_AXIS));
        body.setBorder(BorderFactory.createEmptyBorder(6, 24, 6, 24));

        // Difficulty Card
        JPanel settingsCard = createRoundedCard(COLOR_CARD);
        settingsCard.setLayout(new FlowLayout(FlowLayout.CENTER, 14, 6));

        JLabel diffLabel = new JLabel("Difficulty:");
        diffLabel.setFont(new Font("Segoe UI", Font.BOLD, 13));
        diffLabel.setForeground(COLOR_TEXT_MAIN);

        difficultySelector = new JComboBox<>(Difficulty.values());
        difficultySelector.setSelectedItem(Difficulty.MEDIUM);
        difficultySelector.setFont(new Font("Segoe UI", Font.PLAIN, 13));
        difficultySelector.setBackground(new Color(15, 12, 28));
        difficultySelector.setForeground(COLOR_TEXT_MAIN);
        difficultySelector.setFocusable(false);
        difficultySelector.addActionListener(e -> {
            Difficulty d = (Difficulty) difficultySelector.getSelectedItem();
            if (d != null) startNewGame(d);
        });

        attemptsLabel = new JLabel("Attempts: 7 / 7");
        attemptsLabel.setFont(new Font("Segoe UI", Font.BOLD, 13));
        attemptsLabel.setForeground(COLOR_PRIMARY);

        settingsCard.add(diffLabel);
        settingsCard.add(difficultySelector);
        settingsCard.add(Box.createHorizontalStrut(15));
        settingsCard.add(attemptsLabel);

        body.add(settingsCard);
        body.add(Box.createVerticalStrut(8));

        // Range Slider
        rangeSliderBar = new RangeSliderBar();
        JPanel rangeCard = createRoundedCard(COLOR_CARD);
        rangeCard.setLayout(new BorderLayout());
        rangeCard.add(rangeSliderBar, BorderLayout.CENTER);
        body.add(rangeCard);

        body.add(Box.createVerticalStrut(8));

        // Thermal Proximity & Lifelines
        JPanel lifelineCard = createRoundedCard(new Color(25, 18, 42, 200));
        lifelineCard.setLayout(new FlowLayout(FlowLayout.CENTER, 12, 6));

        thermalLabel = new JLabel("📡 Thermal: Awaiting first guess...", SwingConstants.CENTER);
        thermalLabel.setFont(new Font("Segoe UI", Font.BOLD, 12));
        thermalLabel.setForeground(COLOR_SECONDARY);

        JButton btnParity = createIconButton("⚖️ Even / Odd Clue", e -> {
            sound.playClick();
            String hint = engine.getParityHint();
            updateFeedback("💡 Tactical Lifeline", hint, COLOR_SECONDARY);
        });

        JButton btnDiv = createIconButton("🔍 Divisibility Clue", e -> {
            sound.playClick();
            String hint = engine.getDivisibilityHint();
            updateFeedback("💡 Tactical Lifeline", hint, COLOR_SECONDARY);
        });

        lifelineCard.add(thermalLabel);
        lifelineCard.add(Box.createHorizontalStrut(10));
        lifelineCard.add(btnParity);
        lifelineCard.add(btnDiv);

        body.add(lifelineCard);
        body.add(Box.createVerticalStrut(8));

        // Input Card
        JPanel inputCard = createRoundedCard(COLOR_CARD);
        inputCard.setLayout(new GridBagLayout());
        inputCard.setBorder(BorderFactory.createEmptyBorder(14, 18, 14, 18));

        GridBagConstraints gbc = new GridBagConstraints();
        gbc.insets = new Insets(4, 6, 4, 6);
        gbc.fill = GridBagConstraints.HORIZONTAL;

        JLabel inputPrompt = new JLabel("ENTER YOUR PREDICTION:", SwingConstants.CENTER);
        inputPrompt.setFont(new Font("Segoe UI", Font.BOLD, 13));
        inputPrompt.setForeground(COLOR_TEXT_MUTED);

        guessInputField = new JTextField(6);
        guessInputField.setFont(new Font("Segoe UI", Font.BOLD, 28));
        guessInputField.setHorizontalAlignment(JTextField.CENTER);
        guessInputField.setBackground(new Color(15, 12, 28));
        guessInputField.setForeground(COLOR_TEXT_MAIN);
        guessInputField.setCaretColor(COLOR_PRIMARY);
        guessInputField.setBorder(BorderFactory.createCompoundBorder(
            BorderFactory.createLineBorder(COLOR_PRIMARY, 2, true),
            BorderFactory.createEmptyBorder(4, 12, 4, 12)
        ));

        guessInputField.addKeyListener(new KeyAdapter() {
            @Override
            public void keyPressed(KeyEvent e) {
                if (e.getKeyCode() == KeyEvent.VK_ENTER) {
                    processPlayerGuess();
                }
            }
        });

        submitButton = createStyledButton("SUBMIT GUESS 🎯", COLOR_PRIMARY, COLOR_PRIMARY_HOVER, e -> processPlayerGuess());
        submitButton.setPreferredSize(new Dimension(170, 46));

        gbc.gridx = 0; gbc.gridy = 0; gbc.gridwidth = 2;
        inputCard.add(inputPrompt, gbc);

        gbc.gridx = 0; gbc.gridy = 1; gbc.gridwidth = 1; gbc.weightx = 0.4;
        inputCard.add(guessInputField, gbc);

        gbc.gridx = 1; gbc.gridy = 1; gbc.weightx = 0.6;
        inputCard.add(submitButton, gbc);

        body.add(inputCard);
        body.add(Box.createVerticalStrut(8));

        // Dynamic Feedback Card
        feedbackCard = createRoundedCard(new Color(28, 22, 48, 210));
        feedbackCard.setLayout(new BoxLayout(feedbackCard, BoxLayout.Y_AXIS));
        feedbackCard.setBorder(BorderFactory.createEmptyBorder(12, 16, 12, 16));

        feedbackMessage = new JLabel("Round ready! Enter a number to begin.", SwingConstants.CENTER);
        feedbackMessage.setFont(new Font("Segoe UI", Font.BOLD, 15));
        feedbackMessage.setForeground(COLOR_TEXT_MAIN);
        feedbackMessage.setAlignmentX(Component.CENTER_ALIGNMENT);

        feedbackSubMessage = new JLabel("Pick any number within the highlighted range.", SwingConstants.CENTER);
        feedbackSubMessage.setFont(new Font("Segoe UI", Font.PLAIN, 13));
        feedbackSubMessage.setForeground(COLOR_TEXT_MUTED);
        feedbackSubMessage.setAlignmentX(Component.CENTER_ALIGNMENT);

        feedbackCard.add(feedbackMessage);
        feedbackCard.add(Box.createVerticalStrut(3));
        feedbackCard.add(feedbackSubMessage);

        body.add(feedbackCard);
        body.add(Box.createVerticalStrut(8));

        // History Chips
        JPanel historyContainer = createRoundedCard(new Color(18, 14, 32, 190));
        historyContainer.setLayout(new BorderLayout());
        historyContainer.setBorder(BorderFactory.createEmptyBorder(8, 12, 8, 12));

        JLabel historyTitle = new JLabel("GUESS HISTORY", SwingConstants.LEFT);
        historyTitle.setFont(new Font("Segoe UI", Font.BOLD, 11));
        historyTitle.setForeground(COLOR_TEXT_MUTED);
        historyContainer.add(historyTitle, BorderLayout.NORTH);

        historyChipPanel = new JPanel(new FlowLayout(FlowLayout.LEFT, 8, 4));
        historyChipPanel.setOpaque(false);
        historyContainer.add(historyChipPanel, BorderLayout.CENTER);

        body.add(historyContainer);

        return body;
    }

    private JPanel createFooterPanel() {
        JPanel footer = new JPanel(new FlowLayout(FlowLayout.CENTER, 16, 12));
        footer.setOpaque(false);

        replayButton = createStyledButton("NEW ROUND 🔄", COLOR_ACCENT, new Color(168, 85, 247), e -> {
            sound.playClick();
            startNewGame((Difficulty) difficultySelector.getSelectedItem());
        });
        replayButton.setPreferredSize(new Dimension(150, 42));

        JButton leaderboardButton = createIconButton("🏆 Leaderboard", e -> showLeaderboardDialog());
        leaderboardButton.setPreferredSize(new Dimension(140, 42));

        JButton rulesButton = createIconButton("How to Play ℹ️", e -> showRulesDialog());
        rulesButton.setPreferredSize(new Dimension(130, 42));

        footer.add(replayButton);
        footer.add(leaderboardButton);
        footer.add(rulesButton);

        return footer;
    }

    private void processPlayerGuess() {
        String input = guessInputField.getText().trim();
        if (input.isEmpty()) return;

        int guess;
        try {
            guess = Integer.parseInt(input);
        } catch (NumberFormatException ex) {
            sound.playTooLow();
            updateFeedback("Invalid Input!", "Please enter a valid whole number.", COLOR_WARNING);
            guessInputField.selectAll();
            return;
        }

        GuessResult result = engine.processGuess(guess);
        guessInputField.setText("");
        guessInputField.requestFocusInWindow();

        updateGameStateUI(result);
    }

    private void updateGameStateUI(GuessResult result) {
        int remaining = engine.getRemainingAttempts();
        int max = engine.getMaxAttempts();
        attemptsLabel.setText(String.format("Attempts: %d / %d", remaining, max));

        if (remaining <= 2) {
            attemptsLabel.setForeground(COLOR_DANGER);
        } else if (remaining <= 4) {
            attemptsLabel.setForeground(COLOR_WARNING);
        } else {
            attemptsLabel.setForeground(COLOR_PRIMARY);
        }

        // Thermal Proximity
        if (result.getProximity() != null) {
            thermalLabel.setText("Thermal: " + result.getProximity().getDescription());
        }

        // Range Slider
        List<Integer> pastGuesses = new ArrayList<>();
        for (GuessRecord gr : engine.getGuessHistory()) {
            pastGuesses.add(gr.getGuess());
        }
        rangeSliderBar.updateRange(
            engine.getMinRange(),
            engine.getMaxRange(),
            engine.getNarrowedMin(),
            engine.getNarrowedMax(),
            pastGuesses
        );

        refreshHistoryChips();

        switch (result.getStatus()) {
            case CORRECT -> {
                sound.playVictory();
                confettiPanel.triggerCelebration();
                stats.recordWin(result.getAttemptsUsed(), result.getScoreEarned(), result.getAttemptsRemaining());
                double elapsed = Math.round(((System.currentTimeMillis() - roundStartTime) / 1000.0) * 10.0) / 10.0;
                leaderboard.addEntry(new LeaderboardEntry(playerName, result.getScoreEarned(), result.getAttemptsUsed(), elapsed, engine.getDifficulty().name()));
                updateStatsDisplay();
                updateFeedback(
                    "🎉 BULLSEYE! YOU WON!",
                    String.format("Secret number was %d. Solved in %d guesses (%.1fs)! (+%d pts)",
                        result.getRevealedTarget(), result.getAttemptsUsed(), elapsed, result.getScoreEarned()),
                    COLOR_SUCCESS
                );
                onGameFinished(true);
            }
            case TOO_HIGH -> {
                sound.playTooHigh();
                updateFeedback(
                    String.format("🔻 TOO HIGH! (Guessed: %d)", result.getGuess()),
                    String.format("Target is lower! Zone: [%d ... %d]", engine.getNarrowedMin(), engine.getNarrowedMax()),
                    COLOR_WARNING
                );
            }
            case TOO_LOW -> {
                sound.playTooLow();
                updateFeedback(
                    String.format("🔺 TOO LOW! (Guessed: %d)", result.getGuess()),
                    String.format("Target is higher! Zone: [%d ... %d]", engine.getNarrowedMin(), engine.getNarrowedMax()),
                    COLOR_SECONDARY
                );
            }
            case GAME_OVER -> {
                sound.playGameOver();
                stats.recordLoss();
                updateStatsDisplay();
                updateFeedback(
                    "💀 GAME OVER - OUT OF GUESSES!",
                    String.format("The secret number was %d. Hit 'New Round' to try again!", result.getRevealedTarget()),
                    COLOR_DANGER
                );
                onGameFinished(false);
            }
            case OUT_OF_BOUNDS -> {
                sound.playTooLow();
                updateFeedback("⚠️ OUT OF BOUNDS!", result.getMessage(), COLOR_WARNING);
            }
            case ALREADY_GUESSED -> {
                sound.playTooLow();
                updateFeedback("⚠️ DUPLICATE GUESS!", result.getMessage(), COLOR_WARNING);
            }
        }
    }

    private void onGameFinished(boolean won) {
        guessInputField.setEnabled(false);
        submitButton.setEnabled(false);
        replayButton.setText("PLAY AGAIN 🎮");
        replayButton.requestFocusInWindow();
    }

    private void startNewGame(Difficulty difficulty) {
        confettiPanel.stopCelebration();
        engine.startRound(difficulty);
        roundStartTime = System.currentTimeMillis();

        guessInputField.setEnabled(true);
        submitButton.setEnabled(true);
        replayButton.setText("NEW ROUND 🔄");
        thermalLabel.setText("📡 Thermal: Awaiting first guess...");

        attemptsLabel.setText(String.format("Attempts: %d / %d", engine.getMaxAttempts(), engine.getMaxAttempts()));
        attemptsLabel.setForeground(COLOR_PRIMARY);

        rangeSliderBar.updateRange(
            engine.getMinRange(),
            engine.getMaxRange(),
            engine.getNarrowedMin(),
            engine.getNarrowedMax(),
            new ArrayList<>()
        );

        historyChipPanel.removeAll();
        historyChipPanel.revalidate();
        historyChipPanel.repaint();

        updateFeedback(
            String.format("New Round (%s Mode)!", difficulty.getDisplayName()),
            String.format("Guess the secret number between %d and %d. You have %d attempts.",
                difficulty.getMin(), difficulty.getMax(), difficulty.getMaxAttempts()),
            COLOR_TEXT_MAIN
        );

        guessInputField.setText("");
        SwingUtilities.invokeLater(() -> guessInputField.requestFocusInWindow());
    }

    private void refreshHistoryChips() {
        historyChipPanel.removeAll();
        for (GuessRecord record : engine.getGuessHistory()) {
            JLabel chip = new JLabel();
            chip.setFont(new Font("Segoe UI", Font.BOLD, 12));
            chip.setOpaque(true);
            chip.setBorder(BorderFactory.createEmptyBorder(3, 8, 3, 8));

            switch (record.getStatus()) {
                case TOO_HIGH -> {
                    chip.setText(record.getGuess() + " 🔻");
                    chip.setBackground(new Color(245, 158, 11, 40));
                    chip.setForeground(COLOR_WARNING);
                    chip.setBorder(BorderFactory.createLineBorder(COLOR_WARNING, 1, true));
                }
                case TOO_LOW -> {
                    chip.setText(record.getGuess() + " 🔺");
                    chip.setBackground(new Color(6, 182, 212, 40));
                    chip.setForeground(COLOR_SECONDARY);
                    chip.setBorder(BorderFactory.createLineBorder(COLOR_SECONDARY, 1, true));
                }
                case CORRECT -> {
                    chip.setText(record.getGuess() + " 🎯");
                    chip.setBackground(new Color(16, 185, 129, 40));
                    chip.setForeground(COLOR_SUCCESS);
                    chip.setBorder(BorderFactory.createLineBorder(COLOR_SUCCESS, 1, true));
                }
                case GAME_OVER -> {
                    chip.setText(record.getGuess() + " ✕");
                    chip.setBackground(new Color(239, 68, 68, 40));
                    chip.setForeground(COLOR_DANGER);
                    chip.setBorder(BorderFactory.createLineBorder(COLOR_DANGER, 1, true));
                }
                default -> {}
            }
            historyChipPanel.add(chip);
        }
        historyChipPanel.revalidate();
        historyChipPanel.repaint();
    }

    private void updateFeedback(String title, String subtitle, Color color) {
        feedbackMessage.setText(title);
        feedbackMessage.setForeground(color);
        feedbackSubMessage.setText(subtitle);
        feedbackCard.repaint();
    }

    private void updateStatsDisplay() {
        winsLabel.setText(String.format("🏆 Wins: %d (%.0f%%)", stats.getGamesWon(), stats.getWinRate()));
        streakLabel.setText(String.format("🔥 Streak: %d", stats.getCurrentStreak()));
        scoreLabel.setText(String.format("⭐ Score: %d", stats.getTotalScore()));
    }

    private void showRulesDialog() {
        sound.playClick();
        String message = """
            <html>
            <body style='font-family: Segoe UI, sans-serif; font-size: 13px; color: #1e293b; width: 340px;'>
            <h2 style='color: #db2777; margin-bottom: 4px;'>🎮 How to Play NEO-GUESS ARCADE</h2>
            <hr style='border: 0; border-top: 1px solid #cbd5e1;'/>
            <p><b>1. Goal:</b> Find the secret number before attempts run out.</p>
            <p><b>2. Thermal Proximity:</b> Shows how close you are (Boiling Hot 🔥, Warm ☀️, Chilly ❄️, Freezing 🧊).</p>
            <p><b>3. Tactical Lifelines:</b> Use Even/Odd clues or Divisibility clues when stuck!</p>
            <p><b>4. Range Narrowing:</b> The zone bar narrows with every valid guess.</p>
            <p><b>5. Replay:</b> Keep playing to boost your win streak and high score!</p>
            </body>
            </html>
            """;
        JOptionPane.showMessageDialog(this, message, "Game Rules", JOptionPane.INFORMATION_MESSAGE);
    }

    private void showLeaderboardDialog() {
        sound.playClick();
        List<LeaderboardEntry> entries = leaderboard.getEntries();
        StringBuilder sb = new StringBuilder();
        sb.append("<html><body style='font-family: Segoe UI, sans-serif; width: 420px; color: #1e293b;'>");
        sb.append("<h2 style='color: #db2777; margin-bottom: 4px;'>🏆 Hall of Fame Leaderboard</h2>");
        sb.append("<hr style='border: 0; border-top: 1px solid #cbd5e1; margin-bottom: 8px;'/>");
        sb.append("<table style='width: 100%; border-collapse: collapse; font-size: 13px;'>");
        sb.append("<tr style='background: #f1f5f9; text-align: left;'>");
        sb.append("<th style='padding: 6px;'>Rank</th><th style='padding: 6px;'>Player</th><th style='padding: 6px;'>Score</th><th style='padding: 6px;'>Guesses</th><th style='padding: 6px;'>Time</th></tr>");

        for (int i = 0; i < entries.size(); i++) {
            LeaderboardEntry e = entries.get(i);
            String medal = (i == 0) ? "🥇" : (i == 1) ? "🥈" : (i == 2) ? "🥉" : ("#" + (i + 1));
            sb.append(String.format("<tr><td style='padding: 6px;'><b>%s</b></td><td style='padding: 6px;'>%s</td><td style='padding: 6px; color: #db2777;'><b>%d</b></td><td style='padding: 6px;'>%d</td><td style='padding: 6px; color: #0284c7;'>%.1fs</td></tr>",
                medal, e.getPlayerName(), e.getScore(), e.getAttempts(), e.getTimeSeconds()));
        }
        sb.append("</table></body></html>");
        JOptionPane.showMessageDialog(this, sb.toString(), "Hall of Fame", JOptionPane.INFORMATION_MESSAGE);
    }

    private JPanel createRoundedCard(Color bgColor) {
        return new JPanel() {
            @Override
            protected void paintComponent(Graphics g) {
                super.paintComponent(g);
                Graphics2D g2 = (Graphics2D) g.create();
                g2.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
                g2.setColor(bgColor);
                g2.fill(new RoundRectangle2D.Float(0, 0, getWidth(), getHeight(), 16, 16));
                g2.setColor(COLOR_CARD_BORDER);
                g2.draw(new RoundRectangle2D.Float(0, 0, getWidth() - 1, getHeight() - 1, 16, 16));
                g2.dispose();
            }
            {
                setOpaque(false);
                setBorder(BorderFactory.createEmptyBorder(8, 12, 8, 12));
            }
        };
    }

    private JLabel createStatBadge(String text) {
        JLabel label = new JLabel(text);
        label.setFont(new Font("Segoe UI", Font.BOLD, 13));
        label.setForeground(COLOR_TEXT_MAIN);
        return label;
    }

    private JButton createStyledButton(String text, Color baseColor, Color hoverColor, java.awt.event.ActionListener action) {
        JButton btn = new JButton(text) {
            @Override
            protected void paintComponent(Graphics g) {
                Graphics2D g2 = (Graphics2D) g.create();
                g2.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
                if (getModel().isPressed()) {
                    g2.setColor(baseColor.darker());
                } else if (getModel().isRollover()) {
                    g2.setColor(hoverColor);
                } else {
                    g2.setColor(baseColor);
                }
                g2.fill(new RoundRectangle2D.Float(0, 0, getWidth(), getHeight(), 12, 12));
                g2.dispose();
                super.paintComponent(g);
            }
        };
        btn.setFont(new Font("Segoe UI", Font.BOLD, 14));
        btn.setForeground(Color.WHITE);
        btn.setContentAreaFilled(false);
        btn.setBorderPainted(false);
        btn.setFocusPainted(false);
        btn.setCursor(new Cursor(Cursor.HAND_CURSOR));
        btn.addActionListener(action);
        return btn;
    }

    private JButton createIconButton(String text, java.awt.event.ActionListener action) {
        JButton btn = new JButton(text);
        btn.setFont(new Font("Segoe UI", Font.BOLD, 11));
        btn.setForeground(COLOR_TEXT_MAIN);
        btn.setBackground(new Color(36, 28, 56));
        btn.setFocusPainted(false);
        btn.setCursor(new Cursor(Cursor.HAND_CURSOR));
        btn.setBorder(BorderFactory.createCompoundBorder(
            BorderFactory.createLineBorder(COLOR_CARD_BORDER, 1, true),
            BorderFactory.createEmptyBorder(5, 10, 5, 10)
        ));
        btn.addActionListener(action);
        return btn;
    }
}
