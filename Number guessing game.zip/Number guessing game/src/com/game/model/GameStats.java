package com.game.model;

import java.util.Collections;
import java.util.HashSet;
import java.util.Set;

/**
 * Tracks session statistics across rounds including scores, streaks,
 * and unlocked achievement milestones.
 */
public class GameStats {
    private int gamesPlayed = 0;
    private int gamesWon = 0;
    private int currentStreak = 0;
    private int bestStreak = 0;
    private int highScore = 0;
    private int totalScore = 0;
    private int bestAttempts = Integer.MAX_VALUE;
    private final Set<String> achievements = new HashSet<>();

    public synchronized Set<String> recordWin(int attempts, int score, int remainingAttempts) {
        gamesPlayed++;
        gamesWon++;
        currentStreak++;
        if (currentStreak > bestStreak) {
            bestStreak = currentStreak;
        }
        totalScore += score;
        if (score > highScore) {
            highScore = score;
        }
        if (attempts < bestAttempts) {
            bestAttempts = attempts;
        }

        Set<String> newlyUnlocked = new HashSet<>();

        if (gamesWon == 1 && unlock("First Victory 🔰")) newlyUnlocked.add("First Victory 🔰");
        if (attempts == 1 && unlock("Sniper 🎯")) newlyUnlocked.add("Sniper 🎯");
        if (remainingAttempts == 0 && unlock("Under Pressure ⚡")) newlyUnlocked.add("Under Pressure ⚡");
        if (currentStreak >= 3 && unlock("On Fire 🔥")) newlyUnlocked.add("On Fire 🔥");
        if (currentStreak >= 5 && unlock("Untouchable 👑")) newlyUnlocked.add("Untouchable 👑");
        if (score >= 1000 && unlock("High Roller 💎")) newlyUnlocked.add("High Roller 💎");

        return newlyUnlocked;
    }

    private boolean unlock(String achievement) {
        return achievements.add(achievement);
    }

    public synchronized void recordLoss() {
        gamesPlayed++;
        currentStreak = 0;
    }

    public int getGamesPlayed() { return gamesPlayed; }
    public int getGamesWon() { return gamesWon; }
    public int getCurrentStreak() { return currentStreak; }
    public int getBestStreak() { return bestStreak; }
    public int getHighScore() { return highScore; }
    public int getTotalScore() { return totalScore; }
    public int getBestAttempts() { return bestAttempts == Integer.MAX_VALUE ? 0 : bestAttempts; }

    public double getWinRate() {
        if (gamesPlayed == 0) return 0.0;
        return (double) gamesWon / gamesPlayed * 100.0;
    }

    public Set<String> getAchievements() {
        return Collections.unmodifiableSet(achievements);
    }

    public synchronized void reset() {
        gamesPlayed = 0;
        gamesWon = 0;
        currentStreak = 0;
        bestStreak = 0;
        highScore = 0;
        totalScore = 0;
        bestAttempts = Integer.MAX_VALUE;
        achievements.clear();
    }
}
