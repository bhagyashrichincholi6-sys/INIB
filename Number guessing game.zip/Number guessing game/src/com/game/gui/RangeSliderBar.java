package com.game.gui;

import javax.swing.JComponent;
import java.awt.BasicStroke;
import java.awt.Color;
import java.awt.Dimension;
import java.awt.Font;
import java.awt.GradientPaint;
import java.awt.Graphics;
import java.awt.Graphics2D;
import java.awt.RenderingHints;
import java.awt.geom.RoundRectangle2D;
import java.util.ArrayList;
import java.util.List;

/**
 * Custom visual range indicator illustrating how the search space narrows
 * with each guess made by the player.
 */
public class RangeSliderBar extends JComponent {

    private int totalMin = 1;
    private int totalMax = 100;
    private int currentMin = 1;
    private int currentMax = 100;
    private final List<Integer> pastGuesses = new ArrayList<>();

    private static final Color BG_TRACK = new Color(30, 41, 59); // Slate-800
    private static final Color BORDER_TRACK = new Color(51, 65, 85); // Slate-700
    private static final Color TEXT_MUTED = new Color(148, 163, 184); // Slate-400
    private static final Color TEXT_BRIGHT = new Color(248, 250, 252); // Slate-50
    private static final Color GRADIENT_START = new Color(6, 182, 212); // Cyan-500
    private static final Color GRADIENT_END = new Color(139, 92, 246); // Violet-500
    private static final Color DOT_GUESS = new Color(244, 63, 94); // Rose-500

    public RangeSliderBar() {
        setPreferredSize(new Dimension(480, 56));
        setMinimumSize(new Dimension(300, 50));
    }

    public void updateRange(int totalMin, int totalMax, int currentMin, int currentMax, List<Integer> guesses) {
        this.totalMin = totalMin;
        this.totalMax = totalMax;
        this.currentMin = currentMin;
        this.currentMax = currentMax;
        this.pastGuesses.clear();
        if (guesses != null) {
            this.pastGuesses.addAll(guesses);
        }
        repaint();
    }

    @Override
    protected void paintComponent(Graphics g) {
        super.paintComponent(g);
        Graphics2D g2 = (Graphics2D) g.create();
        g2.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
        g2.setRenderingHint(RenderingHints.KEY_TEXT_ANTIALIASING, RenderingHints.VALUE_TEXT_ANTIALIAS_ON);

        int width = getWidth();
        int height = getHeight();

        int padX = 24;
        int trackY = 22;
        int trackHeight = 12;
        int trackWidth = width - (padX * 2);

        // Draw background track
        g2.setColor(BG_TRACK);
        g2.fill(new RoundRectangle2D.Float(padX, trackY, trackWidth, trackHeight, 10, 10));
        g2.setColor(BORDER_TRACK);
        g2.setStroke(new BasicStroke(1.2f));
        g2.draw(new RoundRectangle2D.Float(padX, trackY, trackWidth, trackHeight, 10, 10));

        // Calculate narrowed active range positions
        double span = Math.max(1, totalMax - totalMin);
        double leftRatio = Math.max(0.0, Math.min(1.0, (double) (currentMin - totalMin) / span));
        double rightRatio = Math.max(0.0, Math.min(1.0, (double) (currentMax - totalMin) / span));

        int activeX = padX + (int) (leftRatio * trackWidth);
        int activeWidth = Math.max(8, (int) ((rightRatio - leftRatio) * trackWidth));

        // Draw active narrowed range with smooth gradient
        GradientPaint gradient = new GradientPaint(
            activeX, trackY, GRADIENT_START,
            activeX + activeWidth, trackY, GRADIENT_END
        );
        g2.setPaint(gradient);
        g2.fill(new RoundRectangle2D.Float(activeX, trackY, activeWidth, trackHeight, 10, 10));

        // Draw past guesses as subtle glowing dots on the track
        for (int guess : pastGuesses) {
            double guessRatio = Math.max(0.0, Math.min(1.0, (double) (guess - totalMin) / span));
            int dotX = padX + (int) (guessRatio * trackWidth);
            g2.setColor(DOT_GUESS);
            g2.fillOval(dotX - 4, trackY + (trackHeight / 2) - 4, 8, 8);
            g2.setColor(Color.WHITE);
            g2.drawOval(dotX - 4, trackY + (trackHeight / 2) - 4, 8, 8);
        }

        // Draw range numbers below and above
        g2.setFont(new Font("Segoe UI", Font.BOLD, 12));

        // Min & Max bounds
        g2.setColor(TEXT_MUTED);
        g2.drawString(String.valueOf(totalMin), padX, trackY - 6);
        String maxStr = String.valueOf(totalMax);
        int maxStrWidth = g2.getFontMetrics().stringWidth(maxStr);
        g2.drawString(maxStr, padX + trackWidth - maxStrWidth, trackY - 6);

        // Active narrowed bounds indicator text
        g2.setColor(TEXT_BRIGHT);
        String narrowedHint = String.format("Active Target Zone: [%d ... %d]", currentMin, currentMax);
        int hintWidth = g2.getFontMetrics().stringWidth(narrowedHint);
        g2.drawString(narrowedHint, (width - hintWidth) / 2, trackY + trackHeight + 16);

        g2.dispose();
    }
}
