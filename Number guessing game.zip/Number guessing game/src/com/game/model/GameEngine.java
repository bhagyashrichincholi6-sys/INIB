package com.game.model;

import java.security.SecureRandom;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.Random;

/**
 * Core engine managing game state, random target generation,
 * guess evaluations, narrowing boundaries, proximity detection,
 * tactical hints, and scoring.
 */
public class GameEngine {

    public enum Status {
        CORRECT,
        TOO_HIGH,
        TOO_LOW,
        OUT_OF_BOUNDS,
        ALREADY_GUESSED,
        GAME_OVER
    }

    public enum Proximity {
        BOILING_HOT("🔥 Boiling Hot! (Within 3)", "#ef4444"),
        WARM("☀️ Warm! (Within 8)", "#f97316"),
        LUKEWARM("⛅ Lukewarm (Within 15)", "#eab308"),
        CHILLY("❄️ Chilly (Within 25)", "#06b6d4"),
        FREEZING("🧊 Freezing Cold", "#3b82f6");

        private final String description;
        private final String colorHex;

        Proximity(String description, String colorHex) {
            this.description = description;
            this.colorHex = colorHex;
        }

        public String getDescription() { return description; }
        public String getColorHex() { return colorHex; }
    }

    public static class GuessRecord {
        private final int guess;
        private final Status status;
        private final Proximity proximity;
        private final int attemptNumber;

        public GuessRecord(int guess, Status status, Proximity proximity, int attemptNumber) {
            this.guess = guess;
            this.status = status;
            this.proximity = proximity;
            this.attemptNumber = attemptNumber;
        }

        public int getGuess() { return guess; }
        public Status getStatus() { return status; }
        public Proximity getProximity() { return proximity; }
        public int getAttemptNumber() { return attemptNumber; }
    }

    public static class GuessResult {
        private final Status status;
        private final String message;
        private final int guess;
        private final Proximity proximity;
        private final int attemptsRemaining;
        private final int attemptsUsed;
        private final int scoreEarned;
        private final Integer revealedTarget;

        public GuessResult(Status status, String message, int guess, Proximity proximity,
                           int attemptsRemaining, int attemptsUsed, int scoreEarned, Integer revealedTarget) {
            this.status = status;
            this.message = message;
            this.guess = guess;
            this.proximity = proximity;
            this.attemptsRemaining = attemptsRemaining;
            this.attemptsUsed = attemptsUsed;
            this.scoreEarned = scoreEarned;
            this.revealedTarget = revealedTarget;
        }

        public Status getStatus() { return status; }
        public String getMessage() { return message; }
        public int getGuess() { return guess; }
        public Proximity getProximity() { return proximity; }
        public int getAttemptsRemaining() { return attemptsRemaining; }
        public int getAttemptsUsed() { return attemptsUsed; }
        public int getScoreEarned() { return scoreEarned; }
        public Integer getRevealedTarget() { return revealedTarget; }

        public boolean isSuccess() {
            return status == Status.CORRECT;
        }

        public boolean isGameOver() {
            return status == Status.CORRECT || status == Status.GAME_OVER;
        }
    }

    private final Random random;
    private Difficulty difficulty;
    private int minRange;
    private int maxRange;
    private int maxAttempts;
    private int targetNumber;
    private int attemptsUsed;
    private int narrowedMin;
    private int narrowedMax;
    private int hintsUsed;
    private boolean isFinished;
    private boolean isWon;
    private final List<GuessRecord> guessHistory;

    public GameEngine() {
        this(new SecureRandom());
    }

    public GameEngine(Random random) {
        this.random = random;
        this.guessHistory = new ArrayList<>();
        startRound(Difficulty.MEDIUM);
    }

    /**
     * Starts a new round with the specified difficulty preset.
     */
    public void startRound(Difficulty difficulty) {
        this.difficulty = difficulty;
        startRound(difficulty.getMin(), difficulty.getMax(), difficulty.getMaxAttempts());
    }

    /**
     * Starts a new round with custom parameters.
     */
    public void startRound(int min, int max, int maxAttempts) {
        if (min >= max) {
            throw new IllegalArgumentException("Min must be strictly less than Max.");
        }
        if (maxAttempts <= 0) {
            throw new IllegalArgumentException("Max attempts must be at least 1.");
        }

        this.minRange = min;
        this.maxRange = max;
        this.maxAttempts = maxAttempts;
        this.narrowedMin = min;
        this.narrowedMax = max;
        this.attemptsUsed = 0;
        this.hintsUsed = 0;
        this.isFinished = false;
        this.isWon = false;
        this.guessHistory.clear();

        // Generate target inclusively in [min, max]
        this.targetNumber = min + random.nextInt(max - min + 1);
    }

    /**
     * Calculates thermal proximity distance between guess and target.
     */
    public Proximity calculateProximity(int guess) {
        int diff = Math.abs(guess - targetNumber);
        if (diff <= 3) return Proximity.BOILING_HOT;
        if (diff <= 8) return Proximity.WARM;
        if (diff <= 15) return Proximity.LUKEWARM;
        if (diff <= 25) return Proximity.CHILLY;
        return Proximity.FREEZING;
    }

    /**
     * Generates an Even or Odd tactical clue.
     */
    public String getParityHint() {
        hintsUsed++;
        return (targetNumber % 2 == 0)
            ? "💡 Parity Clue: The secret number is EVEN."
            : "💡 Parity Clue: The secret number is ODD.";
    }

    /**
     * Generates a divisibility or prime clue.
     */
    public String getDivisibilityHint() {
        hintsUsed++;
        if (targetNumber % 10 == 0) return "💡 Divisibility Clue: The secret number is a multiple of 10!";
        if (targetNumber % 5 == 0) return "💡 Divisibility Clue: The secret number ends in 5 or is divisible by 5.";
        if (targetNumber % 3 == 0) return "💡 Divisibility Clue: The secret number is divisible by 3.";
        if (isPrime(targetNumber)) return "💡 Prime Clue: The secret number is a PRIME number!";
        return "💡 Clue: The sum of digits of the target is " + getDigitSum(targetNumber) + ".";
    }

    private boolean isPrime(int n) {
        if (n <= 1) return false;
        if (n <= 3) return true;
        if (n % 2 == 0 || n % 3 == 0) return false;
        for (int i = 5; i * i <= n; i += 6) {
            if (n % i == 0 || n % (i + 2) == 0) return false;
        }
        return true;
    }

    private int getDigitSum(int n) {
        int sum = 0;
        int temp = Math.abs(n);
        while (temp > 0) {
            sum += temp % 10;
            temp /= 10;
        }
        return sum;
    }

    /**
     * Evaluates a player's guess against the target number.
     */
    public GuessResult processGuess(int guess) {
        if (isFinished) {
            return new GuessResult(
                Status.GAME_OVER,
                "Round already completed. Start a new round to play again!",
                guess,
                null,
                0,
                attemptsUsed,
                0,
                targetNumber
            );
        }

        // Check if out of defined range
        if (guess < minRange || guess > maxRange) {
            return new GuessResult(
                Status.OUT_OF_BOUNDS,
                String.format("Out of bounds! Guess must be between %d and %d.", minRange, maxRange),
                guess,
                null,
                getRemainingAttempts(),
                attemptsUsed,
                0,
                null
            );
        }

        // Check if already guessed
        for (GuessRecord record : guessHistory) {
            if (record.getGuess() == guess) {
                return new GuessResult(
                    Status.ALREADY_GUESSED,
                    String.format("You already guessed %d! Try a different number.", guess),
                    guess,
                    null,
                    getRemainingAttempts(),
                    attemptsUsed,
                    0,
                    null
                );
            }
        }

        // Consume an attempt
        attemptsUsed++;
        int remaining = getRemainingAttempts();
        Proximity proximity = calculateProximity(guess);

        if (guess == targetNumber) {
            isFinished = true;
            isWon = true;
            guessHistory.add(new GuessRecord(guess, Status.CORRECT, proximity, attemptsUsed));
            int score = calculateScore();
            return new GuessResult(
                Status.CORRECT,
                String.format("Spot on! %d was the secret number!", guess),
                guess,
                proximity,
                remaining,
                attemptsUsed,
                score,
                targetNumber
            );
        }

        if (guess < targetNumber) {
            if (guess >= narrowedMin) {
                narrowedMin = guess + 1;
            }
            if (remaining <= 0) {
                isFinished = true;
                isWon = false;
                guessHistory.add(new GuessRecord(guess, Status.GAME_OVER, proximity, attemptsUsed));
                return new GuessResult(
                    Status.GAME_OVER,
                    String.format("Game Over! The secret number was %d.", targetNumber),
                    guess,
                    proximity,
                    0,
                    attemptsUsed,
                    0,
                    targetNumber
                );
            }
            guessHistory.add(new GuessRecord(guess, Status.TOO_LOW, proximity, attemptsUsed));
            return new GuessResult(
                Status.TOO_LOW,
                String.format("Too low! The target is higher than %d.", guess),
                guess,
                proximity,
                remaining,
                attemptsUsed,
                0,
                null
            );
        } else {
            if (guess <= narrowedMax) {
                narrowedMax = guess - 1;
            }
            if (remaining <= 0) {
                isFinished = true;
                isWon = false;
                guessHistory.add(new GuessRecord(guess, Status.GAME_OVER, proximity, attemptsUsed));
                return new GuessResult(
                    Status.GAME_OVER,
                    String.format("Game Over! The secret number was %d.", targetNumber),
                    guess,
                    proximity,
                    0,
                    attemptsUsed,
                    0,
                    targetNumber
                );
            }
            guessHistory.add(new GuessRecord(guess, Status.TOO_HIGH, proximity, attemptsUsed));
            return new GuessResult(
                Status.TOO_HIGH,
                String.format("Too high! The target is lower than %d.", guess),
                guess,
                proximity,
                remaining,
                attemptsUsed,
                0,
                null
            );
        }
    }

    /**
     * Calculates the score based on remaining attempts and difficulty multiplier,
     * deducting points if hints were used.
     */
    public int calculateScore() {
        if (!isWon) return 0;
        int remaining = getRemainingAttempts();
        double multiplier = (difficulty != null) ? difficulty.getScoreMultiplier() : 1.0;
        int base = (remaining + 1) * 150;
        int efficiencyBonus = (attemptsUsed == 1) ? 500 : (attemptsUsed <= 3 ? 200 : 0);
        int hintPenalty = hintsUsed * 50;
        int score = (int) Math.round((base + efficiencyBonus - hintPenalty) * multiplier);
        return Math.max(50, score);
    }

    public int getRemainingAttempts() {
        return Math.max(0, maxAttempts - attemptsUsed);
    }

    public int getMinRange() { return minRange; }
    public int getMaxRange() { return maxRange; }
    public int getNarrowedMin() { return narrowedMin; }
    public int getNarrowedMax() { return narrowedMax; }
    public int getMaxAttempts() { return maxAttempts; }
    public int getAttemptsUsed() { return attemptsUsed; }
    public int getHintsUsed() { return hintsUsed; }
    public boolean isFinished() { return isFinished; }
    public boolean isWon() { return isWon; }
    public Difficulty getDifficulty() { return difficulty; }
    public int getTargetNumber() { return targetNumber; }
    public List<GuessRecord> getGuessHistory() {
        return Collections.unmodifiableList(guessHistory);
    }
}
