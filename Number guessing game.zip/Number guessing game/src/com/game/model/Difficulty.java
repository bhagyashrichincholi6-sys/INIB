package com.game.model;

/**
 * Difficulty levels defining the number range, allowed attempts, and score multiplier.
 */
public enum Difficulty {
    EASY("Easy", 1, 50, 10, 1.0, "1 – 50 (10 Attempts)"),
    MEDIUM("Medium", 1, 100, 7, 1.5, "1 – 100 (7 Attempts)"),
    HARD("Hard", 1, 500, 6, 2.5, "1 – 500 (6 Attempts)"),
    EXPERT("Expert", 1, 1000, 8, 4.0, "1 – 1000 (8 Attempts)");

    private final String displayName;
    private final int min;
    private final int max;
    private final int maxAttempts;
    private final double scoreMultiplier;
    private final String description;

    Difficulty(String displayName, int min, int max, int maxAttempts, double scoreMultiplier, String description) {
        this.displayName = displayName;
        this.min = min;
        this.max = max;
        this.maxAttempts = maxAttempts;
        this.scoreMultiplier = scoreMultiplier;
        this.description = description;
    }

    public String getDisplayName() {
        return displayName;
    }

    public int getMin() {
        return min;
    }

    public int getMax() {
        return max;
    }

    public int getMaxAttempts() {
        return maxAttempts;
    }

    public double getScoreMultiplier() {
        return scoreMultiplier;
    }

    public String getDescription() {
        return description;
    }

    @Override
    public String toString() {
        return displayName;
    }
}
